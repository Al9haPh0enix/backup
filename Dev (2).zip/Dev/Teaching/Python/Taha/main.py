from cmath import rect
import random
import pygame
pygame.init()

w = pygame.display.set_mode((400, 400))
c = pygame.time.Clock()

rectL = []

running = True
while running:
    c.tick(60)
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        
        #if event.type == pygame.KEYDOWN:
    
    keys = pygame.key.get_pressed()

    if keys[pygame.K_e]:
        rectL.append([pygame.Rect(random.randint(0, 400), random.randint(0, 400), 10, 10), 0])
    
    w.fill((127, 127, 127))
    
    for i in range(len(rectL)):
        pygame.draw.rect(w, (min(rectL[i][1], 255), 0, 0), rectL[i][0])
        rectL[i][0].y += 4

        if rectL[i][0].y > 400:
            rectL[i][0].y = 0
            rectL[i][1] += 10
            

    
    pygame.display.flip()
pygame.quit()
