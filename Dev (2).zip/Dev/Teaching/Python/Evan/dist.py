import math

import pygame
pygame.init()

w = pygame.display.set_mode((400, 400))
c = pygame.time.Clock()

running = True
while running:
    c.tick(60)
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
    
    w.fill((127, 127, 127))
    
    p1 = pygame.mouse.get_pos()
    p2 = (200, 200)

    p1r = 10
    p2r = 10

    d = math.dist(p1, p2)

    if d < p1r + p2r:
        pygame.draw.circle(w, (255, 0, 0), (100, 100), 100)

    pygame.draw.circle(w, (255, 255, 255), p1, p1r)
    pygame.draw.circle(w, (255, 255, 255), p2, p2r)

    pygame.display.flip()
pygame.quit()
