
# import gltfLoader

def dist(pos1, pos2):
    out = 0
    for a in range(len(pos1)):
        out += (pos1[a]-pos2[a]) * (pos1[a]-pos2[a])
    return out ** .5

def xAxisRot(pos, center, angle):

    pos[0] -= center[0]
    pos[1] -= center[1]
    pos[2] -= center[2]

    nx = pos[0]
    ny = (pos[1]*math.cos(angle*math.pi/180))-(pos[2]*math.sin(angle*math.pi/180))
    nz = (pos[1]*math.sin(angle*math.pi/180))+(pos[2]*math.cos(angle*math.pi/180))

    pos[0] += center[0]
    pos[1] += center[1]
    pos[2] += center[2]

    return [nx, ny, nz]

def yAxisRot(pos, center, angle):

    pos[0] -= center[0]
    pos[1] -= center[1]
    pos[2] -= center[2]

    nx = (pos[2]*math.sin(angle*math.pi/180))+(pos[0]*math.cos(angle*math.pi/180))
    ny = pos[1]
    nz = (pos[2]*math.cos(angle*math.pi/180))-(pos[0]*math.sin(angle*math.pi/180))

    pos[0] += center[0]
    pos[1] += center[1]
    pos[2] += center[2]

    return [nx, ny, nz]

def zAxisRot(pos, center, angle):

    pos[0] -= center[0]
    pos[1] -= center[1]
    pos[2] -= center[2]

    nx = (pos[0]*math.cos(angle*math.pi/180))-(pos[1]*math.sin(angle*math.pi/180))
    ny = (pos[0]*math.sin(angle*math.pi/180))+(pos[1]*math.cos(angle*math.pi/180))
    nz = pos[2]

    pos[0] += center[0]
    pos[1] += center[1]
    pos[2] += center[2]

    return [nx, ny, nz]

cameraPos = [0, 0, -40]

w, h = 400, 400

planez = 1

import math
import pygame
pygame.init()

w = pygame.display.set_mode((w, h))
c = pygame.time.Clock()

angle = 0

with open("verts.txt", "r") as fv:
    with open("faces.txt", "r") as ff:

        opoints = [[float(j) for j in i.strip().split(" ")] for i in fv.readlines()]
        ofaces = [[int(j) for j in i.strip().split(" ")] for i in ff.readlines()]

        running = True
        while running:

            mx, my = pygame.mouse.get_pos()

            cameraPos[2] = -mx/4

            angle += c.tick(60)/(1000./60.)
            
            if angle >= 360:
                angle = 0
                
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
                if event.type == pygame.MOUSEBUTTONDOWN:
                    if event.button == 4: planez += 1
                    if event.button == 5: planez -= 1
            
            # pygame.display.set_caption(str(planez))

            points = [i for i in opoints]
            faces =  [i for i in ofaces]

            for ind, i in enumerate(points):

                points[ind] = xAxisRot(i, [0, 0, 0], angle)
                points[ind] = yAxisRot(points[ind], [0, 0, 0], angle)
                points[ind] = zAxisRot(points[ind], [0, 0, 0], angle)
            
            w.fill((0, 0, 0))

            centers = []

            for i in faces:
                
                center = [0, 0, 0]

                for j in i:
                    center[0] += points[j][0]
                    center[1] += points[j][1]
                    center[2] += points[j][2]
                center[0] /= len(i)
                center[1] /= len(i)
                center[2] /= len(i)

                centers.append(center)
                
            sortedFaces = []

            faces2 = [i for i in faces]

            while len(faces2) > 0:
                minInd = 0
                minDist = 1000000

                for ind, i in enumerate(centers):
                    d = dist(cameraPos, i)
                    if d < minDist:
                        minInd = ind
                        minDist = d
                
                sortedFaces.append(faces2.pop(minInd))
                centers.pop(minInd)

            sortedFaces.reverse()
            
            for i in sortedFaces:
                verts = []

                for j in i:

                    point = points[j]

                    px = point[0]
                    py = point[1]
                    pz = point[2]
                        
                    dz = pz - cameraPos[2]

                    if dz > 0 and dz < 6000:
                        t = (pz-planez)/dz
                    else:
                        continue

                    X = (cameraPos[0] - px)*t+px
                    Y = (cameraPos[1] - py)*t+py
                    
                    verts.append([X+200, Y+200])
                
                if len(verts) > 2:
                    pygame.draw.polygon(w, (255, 0, 0), verts)
                    pygame.draw.polygon(w, (255, 255, 255), verts, 1)

            pygame.display.flip()
pygame.quit()