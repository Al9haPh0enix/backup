import math
import random
import pygame
pygame.init()

"""
Just ignore the z-axis...
it looks horrible but sometimes works.
Vertices and faces are defined by the user.
"""

w = pygame.display.set_mode((400, 400))
c = pygame.time.Clock()

def nDimDist(point):
    return math.sqrt(sum([i*i for i in point]))

def xAxis(a, point):
    a *= math.pi/180
    x, y, z = point

    nx = x
    ny = y*math.sin(a) - z*math.cos(a)
    nz = y*math.cos(a) + z*math.sin(a)

    return [nx, ny, nz]

def yAxis(a, point):
    a *= math.pi/180
    x, y, z = point

    nx = x*math.cos(a) + z*math.sin(a)
    ny = y
    nz = x*math.cos(a) - z*math.sin(a)

    return [nx, ny, nz]

Points = []

with open("verts.txt") as f:
    Points = [[float(j) for j in i.strip().split(" ")] for i in f.readlines() if i[0:2] != "//"]
    
faces = []

with open("faces.txt") as f:
    faces = [[int(j) for j in i.strip().split(" ")] for i in f.readlines() if i[0:2] != "//"]

# faces = [
#     [0, 1, 2],
#     [0, 3, 2],
#     [4, 5, 6],
#     [4, 7, 6],

#     [0, 1, 5],
#     [0, 4, 5],
#     [3, 2, 6],
#     [3, 7, 6],
    
#     [3, 0, 4],
#     [3, 7, 4],
#     [2, 6, 5],
#     [2, 1, 5],
# ]

a = 0

running = True
while running:
    c.tick(60)
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
    
    w.fill((127, 127, 127))

    a += .5

    #Points = [[j+random.randint(-10, 10)/1000 for j in i] for i in Points]

    nPoints = [xAxis(a, [j+random.randint(-10, 10)/1000 for j in i]) for i in Points]
    nPoints = [yAxis(a, i) for i in nPoints]

    most = -1
    mostI = math.inf

    for i in nPoints:

        d = math.dist([0, 0, -200], i)

        if d > most:
            most = d
            mostI = nPoints.index(i)

    for ind, i in enumerate(faces):
        ps = [[nPoints[j][0]*50+200, nPoints[j][1]*50+200] for j in i]

        for j in i:
            if nPoints[j] == nPoints[mostI]:
                pygame.draw.polygon(w, (int((ind/len(faces))*255), 150, 230), ps)
                break
    
    for ind, i in enumerate(faces):
        ps = [[nPoints[j][0]*50+200, nPoints[j][1]*50+200] for j in i]

        pointInAllowedPoints = False

        for j in i:
            if nPoints[j] == nPoints[mostI]:
                [pygame.draw.circle(w, (0, 127, 127), i, 5) for i in ps]
        
                #pygame.draw.polygon(w, (255, random.randint(127, 255), 0), [(x1*50+200, y1*50+200), (x2*50+200, y2*50+200), (x3*50+200, y3*50+200)])
                pygame.draw.polygon(w, (25, 175, 255), ps, 2)
                break

    pygame.display.flip()
pygame.quit()
