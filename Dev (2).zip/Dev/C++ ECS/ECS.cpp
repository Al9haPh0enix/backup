class entity{
    void entity(){
        
    }
}