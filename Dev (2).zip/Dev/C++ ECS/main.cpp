#include <iostream>

/*
set path=%PATH%;C:/msys64/mingw64/bin
cd "C:\Users\hammersmarkm\Documents\Dev\C++ ECS"
g++ main.cpp & a.exe

*/

int main(){
    float n = 10;
    std::cout<<"1: 0\n";
    int ind = 2;
    for(float i = 0; i <= 1-(1/n); i += 1/(n-1)){
        std::cout<<ind<<": "<<i + 1/(n-1)<<"\n";
        ind++;
    }
}