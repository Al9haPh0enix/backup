class entity{
    void entity();

    //movement
        void setPos(float x, float y);
        void addPos(float x, float y);
        void moveAngle(float angle, float distance);
        void rotate(float angle, float x, float y);
        float* getPos();

    //health
        void setHealth(float health);
        void addHealth(float health);
        float getHealth();
    
    
    //circle collision
        void circleVSpoint(float x, float y);
        void circleVScircle(float x, float y, float radius);
        void circleVSpolygon(float* xs, float* ys);
}