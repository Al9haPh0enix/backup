import numpy as np
import pygame
pygame.init()

def lerp(a, b, k):
    return (k*(b-a))+a

w = pygame.display.set_mode((400, 400))
c = pygame.time.Clock()

width, height = 50, 50

pixels = np.random.random(width*height).reshape(width, height)

running = True
while running:
    c.tick(60)
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
    
    w.fill((127, 127, 127))

    xm = 400/width
    ym = 400/height
    
    npixels = np.zeros(width*height).reshape(width, height)
    
    for x in range(width):
        for y in range(height):
            r = pygame.Rect(x*xm, y*ym, xm, ym)
            col = pixels[x][y]

            left = pixels[x-1][y]
            right = pixels[(x+1)%width][y]
            up = pixels[x][(y+1)%height]
            down = pixels[x][y-1]
            avg = (pixels[x][y]+up+down+left+right)/5

            npixels[x][y] = lerp(pixels[x][y], avg, .5)

            pygame.draw.rect(w, (255*col, 0, 255-255*col), r)
    pixels = lerp(npixels, np.random.random(width*height).reshape(width, height), .1)

    npixels = np.zeros(width*height).reshape(width, height)

    sVal = 1
    shift = 0
    for i in pixels:
        nPixVal = i[int(shift):len(i)]
        for j in i[0:int(shift)]:
            nPixVal = np.append(nPixVal, j)
        npixels[int(shift*sVal)] = nPixVal
        shift += 1/sVal
    pixels = lerp(pixels, npixels, .75)
    
    pixels = npixels
    pixels -= np.min(pixels)
    pixels /= np.max(pixels)
    
    pygame.display.flip()
pygame.quit()
