import random
import pygame
import math
pygame.init()

def shift(arr, pos):

    xshift = pos[0]
    yshift = pos[1]

    na = [[0 for y in range(len(arr))] for x in range(len(arr[0]))]

    for y in range(len(arr)):
        for x in range(len(arr[0])):
            nx = x+xshift
            if nx > len(arr[0])-1:
                nx -= len(arr[0])
            
            ny = y+yshift
            if ny > len(arr[0])-1:
                ny -= len(arr)
            na[nx][ny] = arr[x][y]
    
    return na

width, height = 50, 50

pixels = [[0 for y in range(height)] for x in range(width)]

w = pygame.display.set_mode((400, 400))
c = pygame.time.Clock()

rad = 5

frames = 0

running = True
while running:
    c.tick(60)
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
    
    if pygame.mouse.get_pressed()[0]:
        x, y = pygame.mouse.get_pos()

        x /= 400/width
        y /= 400/height

        x = int(x)
        y = int(y)

        for xx in range(x-rad, x+rad):
            for yy in range(y-rad, y+rad):
                d = math.dist((x, y), (xx, yy))
                if d < rad:
                    try:
                        pixels[int(xx)][int(yy)] = 255
                    except:
                        pass

        
    if frames % 1 == 0:
        na = [[0 for y in range(height)] for x in range(width)]

        for x in range(width):
            for y in range(height):

                av = 0

                av += pixels[x][y]
                av += pixels[x-1][y]
                if x+1 > width-1:
                    av += pixels[x+1-width][y]
                else:
                    av += pixels[x+1][y]
                av += pixels[x][y-1]
                if y+1 > height-1:
                    av += pixels[x][y+1-height]
                else:
                    av += pixels[x][y+1]

                av /= 5
                na[x][y] = min(int(av), 255)
        
        pixels = na
    
    if frames % 2 == 0:
        pixels = shift(pixels, (-1, 0))
    
    w.fill((127, 127, 127))

    snapx = 400/width
    snapy = 400/height
    
    for x, row in enumerate(pixels):
        for y, pix in enumerate(row):
            r = pygame.Rect(x*snapx, y*snapy, snapx, snapy)

            pygame.draw.rect(w, (pix, pix, pix), r)
    
    

    
    pygame.display.flip()

    frames += 1
pygame.quit()
