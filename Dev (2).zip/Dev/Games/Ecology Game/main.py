import math
import random
import pygame
pygame.init()

#Entity: x y calories name

entities = []

for i in range(1):
    entities.append([random.randint(0, 400), random.randint(0, 400), 10, "fern"])
for i in range(0):
    entities.append([random.randint(0, 400), random.randint(0, 400), 3, "deer"])

w = pygame.display.set_mode((400, 400))
c = pygame.time.Clock()

speed = 1/120

frames = 0
timeTick = 30

running = True
while running:
    c.tick(60)
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
    
    w.fill((150, 255, 150))
    
    for e in entities:
        if e[2] == 0:
            entities.remove(e)
        if e[-1] == "fern":
            pygame.draw.circle(w, (50, 200, 100), e[0:2], 3)
            if frames % timeTick==0:
                e[2] += .5
                if e[2] > 7:
                    e[2] -= 7
                    entities.append([e[0]+random.choice([-20, 20]), e[1]+random.choice([-20, 20]), 5, "deer"])
        if e[-1] == "deer":
            pygame.draw.circle(w, (225, 193, 110), e[0:2], 3)
            ld = math.inf
            li = None

            for ind, e2 in enumerate(entities):
                if e2 != e:
                    if e2[-1] == "fern":
                        d = math.dist(e[0:2], e2[0:2])
                        if d < ld:
                            ld = d
                            li = ind

            if li != None:
                if entities[li][0] > e[0]:
                    if math.dist((e[0]+1, e[1]), entities[li][0:2]) >= 6:
                        e[0] += speed * c.get_time()
                if entities[li][0] < e[0]:
                    if math.dist((e[0]-1, e[1]), entities[li][0:2]) >= 6:
                        e[0] -= speed * c.get_time()
                if entities[li][1] > e[1]:
                    if math.dist((e[0], e[1]+1), entities[li][0:2]) >= 6:
                        e[1] += speed * c.get_time()
                if entities[li][1] < e[1]:
                    if math.dist((e[0], e[1]-1), entities[li][0:2]) >= 6:
                        e[1] -= speed * c.get_time()
                if frames % timeTick == 0:
                    if math.dist(e[0:2], entities[li][0:2]) <= 7 and entities[li][2] >= 1:
                        entities[li][2] -= 1
                        e[2] += 1
            if frames % timeTick == 0:
                e[2] -= .5
                if e[2] > 10:
                    e[2] -= 10
                    entities.append([e[0]+random.choice([-20, 20]), e[1]+random.choice([-20, 20]), 5, "deer"])
    if len(entities) <= 2:
        print(entities)

    frames += 1
    
    pygame.display.flip()
pygame.quit()
