import random
import pygame
pygame.init()

w = pygame.display.set_mode((400, 400))
c = pygame.time.Clock()

"""

Creature Dashboard:

+-----------------+
|Name: ###########|
|Species:  #######|
|Strength:    ####|
|Speed:       ####|
|Happiness:   ####|
|Mood:    ########|
+-----------------+

"""

width = height = 20

cursor = [1, 1]

renderCur = True

termScreen = [[" " for y in range(height)] for x in range(width)]

def writeLine(lineNum, line):
    for ind in range(width):
        try:
            termScreen[ind][lineNum] = line[ind]
        except IndexError:
            termScreen[ind][lineNum] = " "
def shift(pos):
    global termScreen

    xshift = pos[0]
    yshift = pos[1]

    na = [[0 for y in range(len(termScreen))] for x in range(len(termScreen[0]))]

    for y in range(len(termScreen)):
        for x in range(len(termScreen[0])):
            nx = x+xshift
            if nx > len(termScreen[0])-1:
                nx -= len(termScreen[0])
            
            ny = y+yshift
            if ny > len(termScreen[0])-1:
                ny -= len(termScreen)
            na[nx][ny] = termScreen[x][y]
    
    termScreen = na

def print(string):
    for ind in range(width):
        try:
            termScreen[ind][cursor[1]] = string[ind]
        except IndexError:
            termScreen[ind][cursor[1]] = " "

font = pygame.font.Font("BlackOpsOne-Regular.ttf", int(400/width))

frames = 0

running = True
while running:
    c.tick(60)
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
    
    w.fill((0, 0, 0))
    
    snapx = 400/width
    snapy = 400/height

    for x in range(width):
        for y in range(height):
            w.blit(font.render(termScreen[x][y][0], True, (0, 255, 0)), (x*snapx, y*snapy))
    
    if frames % 60:
        renderCur = not renderCur
    
    if renderCur:
        w.blit(font.render("_", True, (255, 0, 0)), (cursor[0]*snapx, cursor[1]*snapy))
    
    pygame.display.flip()
    frames += 1
pygame.quit()
