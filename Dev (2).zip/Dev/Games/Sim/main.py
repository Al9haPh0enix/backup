
import math
import random
import pygame
pygame.init()

g = 1

def getMag(x): 
    return math.sqrt(sum(i**2 for i in x))

w = pygame.display.set_mode((400, 400))
c = pygame.time.Clock()

planets = [[random.randint(0, 400), random.randint(0, 400)] for i in range(10)]

stars = [[200, 200]]

planets = [[200, 100]]

vels = [[random.randint(0, 10), random.randint(0, 10)] for i in planets]

vels = [[.5, 0]]

running = True
while running:
    c.tick(60)
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        if event.type == pygame.MOUSEBUTTONDOWN:
            planets.append(list(pygame.mouse.get_pos()))
            vels.append([0, 0])
    
    w.fill((127, 127, 127))

    mx, my = pygame.mouse.get_pos()

    for ind in range(2):
        
        for index, pos in enumerate(planets):
            pygame.draw.circle(w, (255, 0, 0), pos, 1)

            for pos2 in planets:

                if pos != pos2:
                    
                    slope = [pos2[0]-pos[0], pos2[1]-pos[1]]

                    mag = getMag(slope)

                    slope[0]/= mag
                    slope[1]/= mag

                    d = math.dist(pos, pos2)

                    slope[0] /= d
                    slope[1] /= d

                    vels[index][0] += (slope[0]*g)
                    vels[index][1] += (slope[1]*g)
            
            for pos2 in stars:
                slope = [pos2[0]-pos[0], pos2[1]-pos[1]]

                mag = getMag(slope)

                slope[0]/= mag
                slope[1]/= mag

                d = math.dist(pos, pos2)

                slope[0] /= d
                slope[1] /= d

                vels[index][0] += (slope[0]*g)
                vels[index][1] += (slope[1]*g)
        
        # toRem = []
        # toRemv = []

        for i, pos in enumerate(planets):
            planets[i][0] += vels[i][0]
            planets[i][1] += vels[i][1]

        #     for j, pos2 in enumerate(planets):
        #         if pos != pos2:
        #             d = math.dist(pos, planets[i])
        #             if d<2:
        #                 toRem.append(pos)
        #                 toRemv.append(vels[i])

        #                 toRem.append(pos2)
        #                 toRemv.append(vels[j])
        
        # for i in toRem:
        #     planets.remove(i)
        # for i in toRemv:
        #     vels.remove(i)
        
        for pos in stars:
            pygame.draw.circle(w, (255, 255, 0), pos, 3)

    pygame.display.flip()
pygame.quit()
