import sys
import pygame
pygame.init()

w = pygame.display.set_mode((448, 448))
c = pygame.time.Clock()
        
with open("map.level", "r") as f:
    level = [i.strip().split(" ") for i in f.readlines()]

floorIm = pygame.image.load("FloorTile.png")
wallIm = pygame.image.load("WallTile.png")

px, py = 14, 14
    
frames = 0

direc = 0

running = True
while running:
    c.tick(60)
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    keys = pygame.key.get_pressed()

    if keys[pygame.K_RIGHT]:
        direc = 0

    if frames % 10==0:
        if direc == 0:
            px += 1
            
        if direc == 1:
            py += 1
            
        if direc == 2:
            px -= 1
            
        if direc == 3:
            py -= 1
    
    w.fill((127, 127, 127))

    snapx = 448/28
    snapy = 448/28
    
    for x in range(len(level)):
        for y in range(len(level[x])):

            if level[y][x]=="0":
                w.blit(floorIm, (x*snapx, y*snapy))
            if level[y][x]=="1":
                w.blit(wallIm, (x*snapx, y*snapy))
    
    pygame.draw.circle(w, (255, 255, 0), (px*snapx+snapx/2, py*snapy+snapx/2), 8)
    
    pygame.display.flip()
    frames += 1
pygame.quit()
