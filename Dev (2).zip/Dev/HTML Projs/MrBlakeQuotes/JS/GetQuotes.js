window.onload = function(){
    button = document.getElementById("demo");

    button.onclick = function(){
        thing = document.getElementById("idid")
        //txt = 
    }

    document.getElementById('file-selector').addEventListener('change', function() {
      
        var fr=new FileReader();
        fr.onload=function(){
            console.log(fr.result);
        }
      
        fr.readAsText(this.files[0]);
    })
}