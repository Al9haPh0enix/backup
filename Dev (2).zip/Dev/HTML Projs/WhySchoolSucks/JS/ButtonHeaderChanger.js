function func(){
    document.getElementById("demo").style.color = "red";
}