function Render(xtl, ytl, xbr, ybr, col){
    const canvas = document.getElementById('canvas');
    const ctx = canvas.getContext('2d');
    ctx.fillStyle = col;
    ctx.fillRect(xtl, ytl, xbr, ybr);
}

window.onload = function(){
    const canvas = document.getElementById('canvas');
    const ctx = canvas.getContext('2d');
    x = 20;
    y = 20;

    x = canvas.width / 2;
    y = canvas.height/2;

    Render(0 + x, 0 + y, 50 + x, 50 + y, "red");
    Render(12.5 + x, 12.5 + y, 25 + x, 25 + y, "blue");
    console.log("e");
}