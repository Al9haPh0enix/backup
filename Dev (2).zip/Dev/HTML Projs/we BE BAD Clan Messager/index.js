const form  = document.getElementById('messaging');

form.addEventListener('submit', (event) => {
    console.log("submitted");
});