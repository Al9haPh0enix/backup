let angle = 0.0;
let slider;

function setup () {
    createCanvas(400, 400);
    background(0);

    slider = createSlider(0, 10, 0);

    noFill();
    stroke(255);
}

function draw () {
    //background(0);
    translate(width / 2, height / 2)

    stroke(255);
    for(let t = 0; t < slider.value(); t++){
        point(cos(radians(angle)) * angle / 60, sin(radians(angle)) * angle / 60);
        //line(cos(radians(angle)) * angle / 60, sin(radians(angle)) * angle / 60, 0, 0);

        angle += 1;
    }
}