let l = 50;
let a = 90;
let g = 1;

function setup () {
    createCanvas(400, 400);
    background(0);

    //code here

    noFill();
    stroke(255);
}

function draw () {
    background(0);
    translate(width / 2, height / 2);
    
    let x = cos(radians(a - 90)) * l;
    let y = sin(radians(a - 90)) * l;

    ellipse(x, y, 25);
    line(0, 0, x, y);
    fill(255);
    ellipse(0, 0, 5);
    noFill();

    a = g / l * sin(a);

}