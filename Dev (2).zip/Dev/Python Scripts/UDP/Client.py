import socket
import PIL
from PIL import Image

UDP_IP = "127.0.0.1"
UDP_PORT = 5005

image = PIL.Image.open("Cat.png")

image_rgb = image.convert("RGB")

print("UDP target IP: %s" % UDP_IP)
print("UDP target port: %s" % UDP_PORT)

MESSAGE = bytes(image_rgb.getdata())

sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
sock.sendto(MESSAGE, (UDP_IP, UDP_PORT))
