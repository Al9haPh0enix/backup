
import pygame
pygame.init()

import math

iterations = 2

window = pygame.display.set_mode([360 * iterations, 400])


for d in range(100):
    circ_x = 0
    circ_y = 200
    a = 90
    window.fill((255, 255, 255))
    
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
    
    speed = 5

    iterations = 5
    
    for i in range(360 * iterations):
        circ_x += 1
            
        x = math.cos(a * (math.pi/180)) * d
        y = math.sin(a * (math.pi/180)) * d
        
        x += circ_x
        y += circ_y
            
        pygame.draw.circle(window, ((i/(360*iterations))*255, 0, 255), (x, y), 1)
        #pygame.draw.circle(window, (0, 0, 0), (circ_x, circ_y), 25)
        a += iterations
    pygame.time.wait(100)
    pygame.display.flip()
print()

