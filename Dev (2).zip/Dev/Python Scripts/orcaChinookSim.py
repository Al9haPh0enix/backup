import math
import random
import pygame
pygame.init()

w = pygame.display.set_mode((400, 400))
c = pygame.time.Clock()

numOrcas = 1
numChinook = 3

chinookSize = 1
orcaSize    = 10

running = True
while running:
    c.tick(2)
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
    
    if numChinook == 0:
        numChinook = 3
    else:
        numChinook *= 2
    if numOrcas == 0:
        numOrcas = 1
    else:
        numOrcas *= 2

    chinook = [[random.randint(0, 400) for j in range(2)] for i in range(numChinook)]
    orcas   = [[random.randint(0, 400) for j in range(2)] for i in range(numOrcas)]

    numHit = 0
    
    for i in orcas:

        numHitThisIter = 0

        for ch in chinook:
            d = math.dist(i, ch)

            if d < chinookSize + orcaSize:
                numHit += 1
                numHitThisIter += 1
        
        if numHitThisIter < 3:
            numOrcas -= 1
    
    numChinook -= numHit
    
    w.fill((127, 127, 127))
    
    for i in chinook:
        pygame.draw.circle(w, (255, 0, 0), i, chinookSize)
    
    for i in orcas:
        pygame.draw.circle(w, (0, 0, 255), i, orcaSize)
    
    pygame.display.flip()
pygame.quit()
