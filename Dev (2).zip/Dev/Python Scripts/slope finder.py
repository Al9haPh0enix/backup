while True:
    x1 = int(input())
    y1 = int(input())
    print()
    x2 = int(input())
    y2 = int(input())

    X1 = y1-y2
    X2 = x1-x2

    print(str(X1) + "/" + str(X2))
    print()
