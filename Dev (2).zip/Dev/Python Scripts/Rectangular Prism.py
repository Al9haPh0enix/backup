while True:
    F1 = input("F1: ")
    F2 = input("F2: ")

    L1 = input("L1: ")
    L2 = input("L2: ")

    U1 = input("U1: ")
    U2 = input("U2: ")

    F = float(F1) * float(F2)
    B = float(F1) * float(F2)
    L = float(L1) * float(L2)
    R = float(L1) * float(L2)
    U = float(U1) * float(U2)
    D = float(U1) * float(U2)

    print(str(F + B + L + R + U + D))

