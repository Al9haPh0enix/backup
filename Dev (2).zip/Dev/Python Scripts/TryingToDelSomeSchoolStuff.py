File = open("C:\Program Files (x86)\ClassPolicyAgent\PolicyAgent.exe")

content = File.read()

print()

File.close()
