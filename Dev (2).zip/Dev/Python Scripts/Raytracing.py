import pygame
import random
import time

WIDTH = 360
HEIGHT = 480

pygame.init()
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Wierd Polygon")

points = [None] * 10

for i in range(10):
    points[i] = (random.randint(0, WIDTH), random.randint(0, HEIGHT))
    
screen.fill((255, 255, 255))
running = True
while running:

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
    
    for i in range(10):
        points[i] = (random.randint(0, WIDTH), random.randint(0, HEIGHT))

    sur = pygame.Surface((WIDTH, HEIGHT))

    pygame.draw.polygon(sur, (255, 0, 0), points, 6)

    screen.blit(sur, (0, 0))

    pygame.display.flip()

    time.sleep(.1)

pygame.quit()
