import random
import math
import pygame
pygame.init()

w = pygame.display.set_mode((400, 400))
c = pygame.time.Clock()

ps = 5
es = 10
trailLen = 50


enPosL = [[random.randint(0, 400), random.randint(0, 400)], es]
tailPosL = [[0, 0]] * trailLen

lp = (0, 0)

running = True
while running:
    c.tick(60)
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
    
    w.fill((127, 0, 127))

    ltp = tailPosL[0]
    
    for i in range(len(tailPosL)):
        col = (i/trailLen) * 255
        pygame.draw.line(w, (col, col, col), tailPosL[i], ltp, int((trailLen+1)/(i + 1)))
        ltp = tailPosL[i]
    
    if pygame.mouse.get_pos() != lp:
        tailPosL.pop(-1)

        tailPosL.insert(0,list(pygame.mouse.get_pos()))
        lp = pygame.mouse.get_pos()
    
    
    pygame.display.flip()
pygame.quit()
