from PIL import Image

im = Image.open('pie.png') # Can be many different formats.
width, height = im.size

pix = [pixel[:3] for pixel in list(im.getdata())]

pixels = []

x = 0
y = 0

cl = []

for i in range(len(pix)):
    ind = x + (y * width)

    cl.append(pix[i])

    x += 1

    if x == width:
        pixels.append(cl)
        cl = []
        y += 1
        x = 0

print()


with open("out.txt", "w") as f:
    f.write(str(width) + " " + str(height) + "\n")
    for x in range(width):
        out = ""
        for y in range(height):
            out += str(pixels[y][x]).replace("(", "").replace(")", "").replace(" ", "") + " "
        f.write(out + "\n")
