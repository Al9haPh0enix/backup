
import pygame
pygame.init()

S = 3

with open("out.txt") as imag:
    im = [i.strip().split(" ") for i in imag.readlines()]

    w = int(im[0][0])
    h = int(im[0][1])
    im.pop(0)

    for ind in range(len(im)):
        for i in range(len(im[ind])):
            im[ind][i] = [int(c) for c in im[ind][i].split(",")]

win = pygame.display.set_mode((w*S, h*S))
s = pygame.Surface((w*S, h*S))

for x in range(w):
    for y in range(h):
        #print(im[x][y])
        col = (int(im[x][y][0]), int(im[x][y][1]), int(im[x][y][2]))

        r = pygame.Rect(x*S, y*S, S, S)
        pygame.draw.rect(s, col, r)

x = 0
y = 0

running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
    win.fill((0, 255, 0))

    win.blit(s, (x, y))

    pygame.display.flip()