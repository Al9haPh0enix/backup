import math
import random
import sys

width = 100
height = 100

iterations = 10000

def dist(x1, y1, x2, y2):
    
    out = math.sqrt(pow(x2 - x1, 2) + pow(y2 - y1, 2))
    
    return out

def ret(pi, best):
    
    #if abs(math.pi - pi) < 0.075:
    #    print("Difference: " + str(abs(math.pi - pi)) + " : " + str(pi))
    if abs(math.pi - pi) < abs(math.pi - best):
        print(str(pi) + " : " + str(math.pi))
        return pi
    else:
        return best

def recursivePi(iterations, ins, out, best):
    x = random.randint(-width / 2, width / 2)
    y = random.randint(-height / 2, height / 2)
    
    dst = dist(0, 0, x, y) / 50
    
    if abs(dst) < 1:
        if ins + out < iterations:
            if ins != 0 and out != 0:
                best_pi = ret((ins / out), best)
                recursivePi(iterations, ins + 1, out, best_pi)
            else:
                recursivePi(iterations, ins + 1, out, best)
            
    else:
        if ins + out < iterations:
            if ins != 0 and out != 0:
                best_pi = ret((ins / out), best)
                recursivePi(iterations, ins, out + 1, best_pi)
            else:
                recursivePi(iterations, ins, out + 1, best)

sys.setrecursionlimit(iterations)

try:
    recursivePi(50000, 0, 0, 0)
except RecursionError:
    print("We hit pythons recursion limit ):")
