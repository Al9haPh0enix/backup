#https://elyxinternet.herokuapp.com/

import asyncio
import websockets

async def hello():
    uri = "wss://elyxinternet.herokuapp.com/"
    async with websockets.connect(uri) as websocket:
        name = input("Message: ")

        await websocket.send(name)

        greeting = await websocket.recv()
        print(greeting)
