while True:
    r = float(input("Radius: "))

    num = 3.14 * (r * r)

    print("Area: " + str(num))
