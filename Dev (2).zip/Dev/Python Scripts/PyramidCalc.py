numTris = int(input("Number of Triangles: "))

base = float(input("Bottom Area: "))
triB = float(input("Base: "))
triH = float(input("Height: "))

tris = ((triB * triH) / 2) * numTris

print(str(tris + base))
