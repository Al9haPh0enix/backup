import pygame
import math
pygame.init()

w = pygame.display.set_mode((400, 400))
c = pygame.time.Clock()

x1, y1 = 200, 200
x2, y2 = 200, 200

running = True
while running:
    c.tick(60)
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    
    w.fill((127, 127, 127))

    mx, my = pygame.mouse.get_pos()

    keys = pygame.key.get_pressed()

    if keys[pygame.K_SPACE]:
        x1 = mx
        y1 = my
    else:
        x2, y2 = mx, my
    
    a = math.atan2(y2 - y1, x2 - x1) * 180 / math.pi

    x = math.cos(a * math.pi/180) * 100
    y = math.sin(a * math.pi/180) * 100

    pygame.draw.line(w, (0, 0, 255), (x1, y1), (x2, y2), 3)
    pygame.draw.line(w, (255, 0, 0), (x1, y1), (x1 + x, y1 + y), 5)
    
    pygame.display.flip()
pygame.quit()
