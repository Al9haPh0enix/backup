## Initialization ##
import math
import pygame
import random
import glob
from PIL import Image
import os
pygame.init()

## Settings ##
width = 600
height = 600
background = (0, 127, 0)
radius = 2

## Variables ##
clock = pygame.time.Clock()

class wat:
    def __init__(self, x, y):
        self.x = x
        self.y = y

        self.velocity_x = 0
        self.velocity_y = 0

    def run(self, obs):

        toInst = self

        ## Input ##
        keys = pygame.key.get_pressed()

        acceleration_y = -1

        ## Calculating the acceleration using keys without collision ##
        #acceleration_x = movement_speed * (keys[pygame.K_RIGHT] - keys[pygame.K_LEFT])
        #acceleration_y = movement_speed * (keys[pygame.K_DOWN] - keys[pygame.K_UP])

        ## Adding the acceleration to the self.velocity ##
        toInst.velocity_x += (random.randint(-10, 10)/100)
        toInst.velocity_y += acceleration_y + (random.randint(-10, 10)/10)

        for i in obs:
            if i != self:
                if math.dist((i.x, i.y), (toInst.x + toInst.velocity_x, toInst.y + toInst.velocity_y)) < radius*2:
                    
                    i.velocity_x += toInst.velocity_x * .5
                    i.velocity_y += toInst.velocity_y * .5

        ## Edge deflection ##
        if toInst.x + toInst.velocity_x >= width-(radius/2):
            toInst.velocity_x = -toInst.velocity_x/2
        if toInst.x + toInst.velocity_x <= (radius/2):
            toInst.velocity_x = -toInst.velocity_x/2
        if toInst.y + toInst.velocity_y >= width-(radius/2):
            toInst.velocity_y = -toInst.velocity_y/2
        if toInst.y + toInst.velocity_y <= (radius/2):
            toInst.velocity_y = -toInst.velocity_y/2

        ## Adding the self.velocity to the position ##
        toInst.x += toInst.velocity_x * .1
        toInst.y += toInst.velocity_y * .1

        ## Making the self.velocity slow ##
        toInst.velocity_x *= .99
        toInst.velocity_y *= .99

        return toInst
    def render(self, w):
        ## Rendering ##
        pygame.draw.circle(w, (255, 0, 0), (self.x, self.y), radius)

## Variables ##
clock = pygame.time.Clock()

## Window initialization ##
w = pygame.display.set_mode([width, height])
w.fill(background)

obs = [wat(x, y) for x in range(0, 100, 10) for y in range(0, 30, 10)]

for i in obs:
    i.render(w)
pygame.display.flip()
pygame.image.save(w, "sediment_pics/frame" + str(0) + ".png")

## Game Loop ##
ind = 1

running = True
while running:

    ## Event Loop ##
    clock.tick(60)

    for event in pygame.event.get():
        ## Stop when the X is clicked ##
        if event.type == pygame.QUIT:
            running = False

    ## Background ##
    w.fill(background)

    newArr = [None for x in range(0, 100, 10) for y in range(0, 30, 10)]

    for i in range(len(obs)):
        newArr[i] = obs[i].run(obs)
    obs = newArr
    
    for i in obs:
        i.render(w)
    pygame.display.flip()
    pygame.image.save(w, "sediment_pics/frame" + str(ind) + ".png")
    ind += 1

fp_in = "sediment_pics/frame*.png"
fp_out = "Sed.gif"

img, *imgs = [Image.open(f) for f in sorted(glob.glob(fp_in))]
img.save(fp=fp_out, format='GIF', append_images=imgs,
         save_all=True, duration=50, loop=0)
for f in glob.glob(fp_in):
    os.remove(f)

## Close the window ##
pygame.quit()