import random
import pygame
import pygame.freetype
pygame.init()

w = pygame.display.set_mode((400, 400))
c = pygame.time.Clock()

font = pygame.freetype.Font("BlackOpsOne-Regular.ttf", 20)

width = height = 20

xed = False
respawnRect = pygame.Rect(150, 200, 100, 50)

ld = 0
trying = True
while trying:
    snakeL = [[0 for x in range(width)] for y in range(height)]

    snakeL[10][10] = 1

    snakeLen = 1
    sh = [10, 10]
    gridS = 1

    timer = 0

    d = 0

    score = 0

    applePos = [random.randint(0, 19), random.randint(0, 19)]
    running = True
    while running:
        timer += c.tick(60)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
                xed = True
            
            if event.type == pygame.KEYDOWN:
                if (event.key == pygame.K_a or event.key == pygame.K_LEFT) and ld != 2:
                    d = 0
                if (event.key == pygame.K_s or event.key == pygame.K_DOWN) and ld != 3:
                    d = 1
                if (event.key == pygame.K_d or event.key == pygame.K_RIGHT) and ld != 0:
                    d = 2
                if (event.key == pygame.K_w or event.key == pygame.K_UP) and ld != 1:
                    d = 3
        
        w.fill((127, 127, 127))

        keys = pygame.key.get_pressed()
        
        for x in range(width):
            for y in range(height):
                r = pygame.Rect(x * (400/width)+gridS, y * (400/height)+gridS, (400/width)-(gridS*2), (400/height)-(gridS*2))
                col = 255 * (snakeL[x][y] != 0)
                pygame.draw.rect(w, (col, col, col), r)
        
        r = pygame.Rect(sh[0] * (400/width) + gridS, sh[1] * (400/height) + gridS, (400/width) - (gridS*2), (400/height) - (gridS*2))
        a = pygame.Rect(applePos[0] * (400/width) + gridS, applePos[1] * (400/height) + gridS, (400/width) - (gridS*2), (400/height) - (gridS*2))
        pygame.draw.rect(w, (0, 255, 0), r)
        pygame.draw.rect(w, (255, 0, 0), a)

        if pygame.key.get_pressed()[pygame.K_SPACE] and timer > 150:
            for x in range(width):
                for y in range(height):
                    snakeL[x][y] -= 1
                    if snakeL[x][y] < 0:
                        snakeL[x][y] = 0
            
            pygame.display.set_caption(str(score))
            
            if d == 0:
                sh[0] -= 1
            if d == 1:
                sh[1] += 1
            if d == 2:
                sh[0] += 1
            if d == 3:
                sh[1] -= 1

            sh[0] = sh[0] % width
            sh[1] = sh[1] % height

            if snakeL[sh[0]][sh[1]] != 0:
                running = False
            
            if sh == applePos:
                score += 1
                applePos = [random.randint(0, 19), random.randint(0, 19)]
                while snakeL[applePos[0]][applePos[1]] > 0:
                    applePos = [random.randint(0, 19), random.randint(0, 19)]
                snakeLen += 1
                for x in range(width):
                    for y in range(height):
                        if snakeL[x][y] != 0:
                            snakeL[x][y] += 1

            snakeL[sh[0]][sh[1]] = snakeLen
            
            timer = 0
            ld = d
        
        pygame.display.flip()
    
    trying = not xed
    while trying:
        c.tick(60)
        end = False
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
                xed = True
                trying = False
            
            if event.type == pygame.MOUSEBUTTONDOWN:
                x, y = pygame.mouse.get_pos()
                if x < respawnRect.x + respawnRect.width and x > respawnRect.x:
                    if y < respawnRect.y + respawnRect.height and y > respawnRect.y:
                        end = True
                        break
        if end:
            break
        
        w.fill((127, 127, 127))

        pygame.draw.rect(w, (50, 50, 50), respawnRect)

        t = font.get_rect("Respawn")

        font.render_to(w, (respawnRect.x - (t.width/2) + (respawnRect.width/2), respawnRect.y - (t.height/2) + (respawnRect.height/2)), "Respawn", (255, 255, 255))

        if xed:
            break

        pygame.display.flip()
pygame.quit()
