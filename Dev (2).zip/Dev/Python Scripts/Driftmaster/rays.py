
import pygame
import math

pygame.init()

def dist(x1, y1, x2, y2):
    return math.sqrt( (x2 - x1)**2 + (y2 - y1)**2 )

def get_line_intersection(p0_x, p0_y, p1_x, p1_y, p2_x, p2_y, p3_x, p3_y):
    s1_x = p1_x - p0_x     
    s1_y = p1_y - p0_y
    s2_x = p3_x - p2_x     
    s2_y = p3_y - p2_y

    s = 0
    t = 0
    s = (-s1_y * (p0_x - p2_x) + s1_x * (p0_y - p2_y)) / (-s2_x * s1_y + s1_x * s2_y)
    t = ( s2_x * (p0_y - p2_y) - s2_y * (p0_x - p2_x)) / (-s2_x * s1_y + s1_x * s2_y)

    if (s >= 0 and s <= 1 and t >= 0 and t <= 1):
        # Collision detected
        outx = p0_x + (t * s1_x)
        outy = p0_y + (t * s1_y)
        return (outx, outy)
    

    return 0 # No collision


def Raycast(x, y, angle, ps, m = 600, s = 1):
    xa = math.cos(angle * (math.pi/180))*s
    ya = math.sin(angle * (math.pi/180))*s
    for i in range(int(m/s)):
        x += xa
        y += ya

        xx = 0
        yy = 0

        ld = 0

        p = None

        for ind in range(0, len(ps), 4):
            p1 = ps[ind]
            p2 = ps[ind+1]

            o = get_line_intersection(p1[0], p1[1], p2[0], p2[1])

            if o == 0:
                continue
        
            d = dist(x, y, o[0], o[1])
        
        if p == None:
            ht = 0
        else:
            ht = 1
            break
    return (x, y, ht)

w = pygame.display.set_mode([800, 400])
c = pygame.time.Clock()

x, y = (200, 200)
a = 0
av = 0

S = 6
ts = 10

#sp = tsk.Sprite("OrbGreenSymbol.png", x, y)
#sp.scale = 0.25

#sp.x -= sp.width/2
#sp.y -= sp.height/2

vx = 0
vy = 0

running = True
while running:
    c.tick(30)
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
    w.fill((0, 0, 0))
    
    keys = pygame.key.get_pressed()
    
    if keys[pygame.K_LEFT]:
        av -= ts
    
    if keys[pygame.K_RIGHT]:
        av += ts
    
    a += av
    
    av *= .5
    
    cosx = math.cos(a * (math.pi/180))
    siny = math.sin(a * (math.pi/180))
    
    s = 0
    
    if keys[pygame.K_UP]:
        s = S
    
    if keys[pygame.K_DOWN]:
        s = -S
    
    if x + cosx*s < 385 and x + cosx*s > 15:
        vx += cosx * s
    if y + siny*s < 385 and y + siny*s > 15:
        vy += siny * s
    
    
    if x + vx < 385 and x + vx > 15:
        x += vx
    else:
        vx *= -.5
        
    if y + vy < 385 and y + vy > 15:
        y += vy
    else:
        vy *= -.5
        
        
    #sp.x = x - sp.width/2
    #sp.y = y - sp.height/2
    #sp.angle = -a-90
    #sp.draw()

    rays = []
    
    pygame.draw.circle(w, (255, 0, 0), (100, 100), 50)
    for i in range(-45 + int(a), 45 + int(a), 1):
        ray = Raycast(x, y, i, [(0, 0), (100, 100)], s=2)
        rays.append(ray)
        pygame.draw.line(w, (100, 0, 0), (x, y), (ray[0], ray[1]), 1)
    
    vx *= .9
    vy *= .9
    
    pygame.draw.circle(w, (200, 200, 0), (x, y), 15)
    pygame.draw.circle(w, (0, 0, 0), (x + cosx*15, y + siny*15), 3)

    #render:
    r = 0
    for i in rays:
        d = dist(x, y, i[0], i[1])

        x1 = ((r/90)*400)+400

        print(x1)

        rec = pygame.Rect(x1, 0, 400/90, 400)
        pygame.draw.rect(w, (255 * i[2], 255, 255), rec)
        r += 1

    pygame.display.flip()
pygame.quit()