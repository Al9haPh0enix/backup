## Initialization ##
import math
import pygame
pygame.init()

## Settings ##
movement_speed = .75
width = 600
height = 600
background = (0, 127, 0)
radius = 5

## Variables ##
x = 10
y = 300
angle = 0
clock = pygame.time.Clock()
velocity_x = 0
velocity_y = 0
mvelocity_x = 20
mvelocity_y = 20
timerx = 0
timery = 0

px = x
py = y

## Window initialization ##
w = pygame.display.set_mode([width, height])
w.fill(background)

## Game Loop ##
running = True
while running:

    ## Event Loop ##
    clock.tick(60)

    timerx += clock.get_time()
    timery += clock.get_time()

    for event in pygame.event.get():
        ## Stop when the X is clicked ##
        if event.type == pygame.QUIT:
            running = False

    ## Background ##
    bw = w.copy()
    bw.set_alpha(240)

    w.fill(background)
    w.blit(bw, (0, 0))

    ## Input ##
    keys = pygame.key.get_pressed()

    #acceleration_x = movement_speed * (keys[pygame.K_RIGHT] - keys[pygame.K_LEFT])
    #acceleration_y = movement_speed * (keys[pygame.K_DOWN] - keys[pygame.K_UP])
    acceleration_x = 0
    acceleration_y = 0

    
    if x <= width - (radius/2):
        acceleration_x += movement_speed * keys[pygame.K_RIGHT]
    if x >= radius/2:
        acceleration_x += movement_speed * -keys[pygame.K_LEFT]
    if y <= height - (radius/2):
        acceleration_y += movement_speed * keys[pygame.K_DOWN]
    if y >= radius/2:
        acceleration_y += movement_speed * -keys[pygame.K_UP]
    
    ## Calculating the acceleration using keys without collision ##
    #acceleration_x = movement_speed * (keys[pygame.K_RIGHT] - keys[pygame.K_LEFT])
    #acceleration_y = movement_speed * (keys[pygame.K_DOWN] - keys[pygame.K_UP])

    ## Adding the acceleration to the velocity ##
    velocity_x += acceleration_x
    velocity_y += acceleration_y

    ## Edge deflection ##
    if x + velocity_x > width-(radius/2):
        velocity_x = -velocity_x/2
    if x + velocity_x < (radius/2):
        velocity_x = -velocity_x/2
    if y + velocity_y > width-(radius/2):
        velocity_y = -velocity_y/2
    if y + velocity_y < (radius/2):
        velocity_y = -velocity_y/2

    """
    ## Track ##
    if x >= (width/4-(radius/2)) and x <= width - (width/4-(radius/2)):
        velocity_x = -velocity_x/2
        if y >= (height/4-(radius/2)) and y <= height - (height/4-(radius/2)):
            pygame.draw.circle(w, (255, 0, 0), (width/2, height/2), 200)
    """
    
    ## Adding the velocity to the position ##
    x += velocity_x
    y += velocity_y

    ## Making the velocity slow ##
    velocity_x *= .99999
    velocity_y *= .99999

    ## Colors ##
    """
    if mvelocity_x > 0 and mvelocity_y > 0:
        v1 = (abs(velocity_x) / mvelocity_x)*225
        v2 = (abs(velocity_y) / mvelocity_y)*255
        v = min((v1 + v2) / 2, 255)

        v = min(max(0,v), 255)

        v = 255 - v
  
        col = (v, v, v)
    else:
        col = (0, 0, 0)
    """

    col = (255, 255, 255)

    ## Rendering ##
    #pygame.draw.circle(w, col, (x, y), radius)
    pygame.draw.line(w, col, (x, y), (x - velocity_x, y - velocity_y), radius * 2)
    pygame.display.flip()

    px = x
    py = y

## Close the window ##
pygame.quit()
    