
import pygame
import tsk
pygame.init()

w = pygame.display.set_mode((400, 400))
c = pygame.time.Clock()

sprites = []
vels = []

running = True
while running:
    c.tick(60)
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        
        if event.type == pygame.MOUSEBUTTONDOWN:
            x, y = pygame.mouse.get_pos()
            sprite = tsk.Sprite("Basketball.png", x, y)
            sprites.append(sprite)

            #https://codeprojects.org/LTuim4N_a-0QD5qzyZdiaZ2ECBVdM_L3OMClih9upTc

            vels.append([10, 10])
    
    w.fill((127, 127, 127))
    
    for i in range(len(sprites)):

        vels[i][0] *= .99
        vels[i][1] *= .99

        vx, vy = vels[i]

        if sprites[i].center_x + vx >= 0 and sprites[i].center_x + vx <= 400:
            sprites[i].center_x += vx
        else:
            vels[i][0] *= -.5
        if sprites[i].center_y + vy >= 0 and sprites[i].center_y + vy <= 400:
            sprites[i].center_y += vy
        else:
            vels[i][1] *= -.5
        sprites[i].draw()
    
    pygame.display.flip()
