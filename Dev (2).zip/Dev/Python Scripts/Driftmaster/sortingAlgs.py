import math
import random

import pygame
pygame.init()

def renderArr(w, arr, c):
    w.fill((0, 0, 0))

    ind = 0 
    for i in arr:
        pygame.draw.line(w, c, (ind, 400), (ind, 400 - i))
        ind += 1
    pygame.display.flip()

def partition(arr, low, high):
    i = (low-1)         # index of smaller element
    pivot = arr[high]     # pivot
 
    for j in range(low, high):
 
        # If current element is smaller than or
        # equal to pivot
        if arr[j] <= pivot:
 
            # increment index of smaller element
            i = i+1
            arr[i], arr[j] = arr[j], arr[i]
 
    arr[i+1], arr[high] = arr[high], arr[i+1]
    return (i+1)
 
def quickSort(arr, low, high, w):
    if len(arr) == 1:
        return arr
    if low < high:
 
        # pi is partitioning index, arr[p] is now
        # at right place
        pi = partition(arr, low, high)

        renderArr(w, arr, (0, 0, 255))
        pygame.draw.line(w, (255, 0, 0), (pi, 0), (pi, 800), 3)
        pygame.display.flip()
 
        # Separately sort elements before
        # partition and after partition
        quickSort(arr, low, pi-1, w)
        quickSort(arr, pi+1, high, w)

w = pygame.display.set_mode([800, 400])

arr = [i/2 for i in range(800)]
random.shuffle(arr)

n = len(arr)

running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
    
    renderArr(w, arr, (255, 0, 0))
    pygame.time.wait(1000)
    quickSort(arr, 0, n - 1, w)
    renderArr(w, arr, (0, 255, 0))
    arr = [i/2 for i in range(800)]
    random.shuffle(arr)
    pygame.time.wait(1000)
pygame.quit()