import random

list_1 = [1, 2, 3, 4, 5]

print(list_1)

for i in range(3):
    fire_bullet()
    print(i)