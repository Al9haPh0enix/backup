import random
import pygame
pygame.init()

w = pygame.display.set_mode([400, 400])

font = pygame.font.Font(None, 25)

w.fill((255, 255, 255))

cx1 = 100
cy1 = 200

cx2 = 300
cy2 = 200


cx3 = 200
cy3 = 300

cx4 = 200
cy4 = 100


num1 = random.randint(-12, 12)
num2 = random.randint(-12, 12)

score = 0
running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    w.fill((255, 255, 255))

    pygame.draw.line(w, (0, 0, 0), (50, 50), (350, 350), 3)
    pygame.draw.line(w, (0, 0, 0), (50, 350), (350, 50), 3)

    numAt = font.render(str(num1+num2), True, (0, 0, 0))
    text_rect = numAt.get_rect(center=(cx3, cy3))
    w.blit(numAt, text_rect)

    numMt = font.render(str(num1*num2), True, (0, 0, 0))
    text_rect = numMt.get_rect(center=(cx4, cy4))
    w.blit(numMt, text_rect)

    pygame.display.flip()

    print("x1 + x2 =", num1 + num2)
    print("x1 * x2 =", num1 * num2)
    print()
    num1g = int(input("What is x1? "))
    num2g = int(input("What is x2? "))

    c = False

    if num1g * num2g == num1*num2:
        if num1g + num2g == num1+num2:
            c = True
    
    #if abs(num1g) == abs(num1) or abs(num1g) == abs(num2g):
        #if abs(num2g) == abs(num1) or abs(num2g) == abs(num2g):
            #if num1g < 0 and num1 > 0 and num2g > 0 and num2 < 0:
            #    pass
            #if num1g > 0 and num1 < 0 and num2g < 0 and num2 > 0:
            #    pass

    if c:
        score += 1
        num1 = random.randint(-12, 12)
        num2 = random.randint(-12, 12)
        continue
    else:
        print("\nWrong! it was x1=", num1, "x2=", num2, "\n")