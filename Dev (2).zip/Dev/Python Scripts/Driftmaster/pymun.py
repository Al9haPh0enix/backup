
# Python imports
import random
from typing import List

# Library imports
import pygame

# pymunk imports
import pymunk
import pymunk.util as u
import pymunk.pygame_util

def jarvis_march(points):
    # find the leftmost point
    a =  min(points, key = lambda point: point[0])
    index = points.index(a)
    
    # selection sort
    l = index
    result = []
    result.append(a)
    while (True):
        q = (l + 1) % len(points)
        for i in range(len(points)):
            if i == l:
                continue
            # find the greatest left turn
            # in case of collinearity, consider the farthest point
            d = direction(points[l], points[i], points[q])
            if d > 0 or (d == 0 and distance_sq(points[i], points[l]) > distance_sq(points[q], points[l])):
                q = i
        l = q
        if l == index:
            break
        result.append(points[q])

    return result


def polyInside(x,y,poly):

    n = len(poly)
    inside = False

    p1x,p1y = poly[0]
    for i in range(n+1):
        p2x,p2y = poly[i % n]
        if y > min(p1y,p2y):
            if y <= max(p1y,p2y):
                if x <= max(p1x,p2x):
                    if p1y != p2y:
                        xints = (y-p1y)*(p2x-p1x)/(p2y-p1y)+p1x
                    if p1x == p2x or x <= xints:
                        inside = not inside
        p1x,p1y = p2x,p2y

    return inside


class Bouncyshapes(object):
    """
    This class implements a simple scene in which there is a static platform (made up of a couple of lines)
    that don't move. shapes appear occasionally and drop onto the platform. They bounce around.
    """

    def __init__(self):
        # Space
        self.space = pymunk.Space()
        self.space.gravity = (0, 900.0)

        # Physics
        # Time step
        self.dt = 1.0 / 60.0
        # Number of physics steps per screen frame
        self._physics_steps_per_frame = 1

        # pygame
        pygame.init()
        self.w = pygame.display.set_mode((600, 600))
        self.c = pygame.time.Clock()

        self._draw_options = pymunk.pygame_util.DrawOptions(self.w)

        # Static barrier walls (lines) that the shapes bounce off of
        static_body = self.space.static_body
        static_lines = [
            pymunk.Segment(static_body, a=(100, 300), b=(500, 400), radius=5.0),
            #pymunk.Segment(static_body, a=(500, 400), b=(500, 100), radius=5.0),
        ]
        for line in static_lines:
            line.elasticity = 0.95
            line.friction = 0.9
        self.space.add(*static_lines)

        # shapes that exist in the world
        self.shapes: List[pymunk.Circle] = []

        # Execution control and time until the next ball spawns
        self.running = True
        self._ticks_to_next_ball = 10

    def run(self):

        self.drawing = False
        self.points = []

        self.drt = 0
        self.drtt = 10

        """
        The main loop of the game.
        :return: None
        """
        # Main loop
        while self.running:
            # Progress time forward
            for x in range(self._physics_steps_per_frame):
                self.space.step(self.dt)
            
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    self.running = False
                
                elif event.type == pygame.MOUSEBUTTONDOWN:
                    self.drawing = True
                elif event.type == pygame.MOUSEBUTTONUP:
                    self.drawing = False
                    center = u.calc_center(self.points)

                    for i in range(len(self.points)):
                        self.points[i][0] -= center[0]
                        self.points[i][1] -= center[1]

                    self.drawPoly(self.points, center)
                    self.points = []
            
            self.drt += self.c.get_time()

            if self.drawing and self.drt > self.drtt:
                self.points.append(list(pygame.mouse.get_pos()))

                if len(self.points) > 1 and polyInside(self.points[-1][0], self.points[-1][1], self.points[0:len(self.points)-1]):
                    self.points = jarvis_march(self.points)

                self.drt = 0
            


            self._updateshapes()
            self.w.fill(pygame.Color("white"))
            self.space.debug_draw(self._draw_options)

            if len(self.points) > 1:
                pygame.draw.polygon(self.w, (255, 0, 0), self.points, 2)

            pygame.display.flip()
            
            self.dt = self.c.tick(60)/1000

            pygame.display.set_caption("fps: " + str(self.c.get_fps()))

    def _updateshapes(self):
        self._ticks_to_next_ball -= 1
        if self._ticks_to_next_ball <= 0:
            self._create_shapes()
            self._ticks_to_next_ball = 100
        # Remove shapes that fall below 100 vertically
        shapes_to_remove = [ball for ball in self.shapes if ball.body.position.y > 500]
        for ball in shapes_to_remove:
            self.space.remove(ball, ball.body)
            self.shapes.remove(ball)
    
    def drawPoly(self, points, center = (0, 0)):
        
        mass = 10
        moment = pymunk.moment_for_poly(mass, points)
        # moment = 1000
        body = pymunk.Body(mass, moment)
        body.position = center
        shape = pymunk.Poly(body, points)
        shape.friction = 0.5
        shape.collision_type = 1
        self.space.add(body, shape)
        self.shapes.append(shape)

    def _create_shapes(self):
        
        radius = random.randint(25, 35)
        mass = radius/2.5
        inertia = pymunk.moment_for_circle(mass, 0, radius, (0, 0))
        body = pymunk.Body(mass, inertia)
        x = random.randint(115, 350)
        body.position = x, 200
        shape = pymunk.Circle(body, radius, (0, 0))
        shape.elasticity = 0
        shape.friction = 0.9
        self.space.add(body, shape)
        self.shapes.append(shape)

        size = random.randint(10, 20)
        points = [(-size, -size), (-size, size), (size, size), (size, -size)]
        mass = size/10
        moment = pymunk.moment_for_poly(mass, points, (0, 0))
        body = pymunk.Body(mass, moment)
        body.position = (x, 100)
        shape = pymunk.Poly(body, points)
        shape.friction = 1
        self.space.add(body, shape)
        self.shapes.append(shape)

        moment = pymunk.moment_for_poly(mass, points)
        body = pymunk.Body(mass, moment)
        body.position = x, 0
        shape = pymunk.Poly(body, [(-size, 0), (size, 0), (0, size)])
        shape.friction = 0.5
        shape.collision_type = 0
        self.space.add(body, shape)
        self.shapes.append(shape)


if __name__ == "__main__":
    game = Bouncyshapes()
    game.run()