import math
import pygame
pygame.init()

width = height = 400

w = pygame.display.set_mode([width, height])

running = True
while running:

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
    
    w.fill((255, 255, 255))

    mx, my = pygame.mouse.get_pos()

    lx = math.cos(0) * 100 + mx
    ly = math.sin(0) * 100 + my

    for a in range(0, 360):
        x = math.cos(a * (math.pi/180)) * 100 + mx
        y = math.sin(a * (math.pi/180)) * 100 + my

        pygame.draw.line(w, (0, 0, 0), (lx, ly), (x, y), 3)
        lx = x
        ly = y

    pygame.display.flip()
pygame.quit()