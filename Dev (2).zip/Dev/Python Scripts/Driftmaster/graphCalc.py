import math
import re

import pygame
pygame.init()

g = 25

def getPos(x, func):
    
    func = func.replace("x^2", "x*x")
    func = func.replace("x^3", "x*x*x")
    func = func.replace("x^", "abs(x)**")
    func = func.replace("x", str(x))
    func = func.replace("/0", "*0")
    func = func.replace("sin", "math.sin")
    func = func.replace("cos", "math.cos")
    func = func.replace("pi", "math.pi")
    loc = {}


    exec(func, globals(), loc)
    return_workaround = loc['y']

    return(return_workaround * g)

w = pygame.display.set_mode([400, 400])
w.fill((0, 0, 0))

func  = "y = sin(x) / 3"
func2 = "y = cos(x)"

c1 = (255, 255, 255)
c2 = (0, 200, 0)

lx = 0
ly = getPos(-200 / g, func) + 200

for x in range(0, 400, g):
    pygame.draw.line(w, (127, 127, 127), (x, 0), (x, 400), 1)
for y in range(0, 400, g):
    pygame.draw.line(w, (127, 127, 127), (0, y), (400, y), 1)

pygame.draw.line(w, (127, 0, 0), (200, 0), (200, 400), 1)
pygame.draw.line(w, (127, 0, 0), (0, 200), (400, 200), 1)

for x in range(400):
    y = (getPos((x - 200) / g, func)) + 200

    if ly < 0 or ly > 400:
        lx = x
        ly = y
    else:
        pygame.draw.line(w, c1, (x, 400 - y), (lx, 400 - ly), 1)
    if y < 0 or y > 400:
        continue

    pygame.draw.line(w, c1, (x, 400 - y), (lx, 400 - ly), 1)

    lx = x
    ly = y

if func2 != "":
    lx = 0
    ly = getPos(-200 / g, func2) + 200

    for x in range(400):
        y = (getPos((x - 200) / g, func2)) + 200

        if ly < 0 or ly > 400:
            lx = x
            ly = y
        else:
            pygame.draw.line(w, c2, (x, 400 - y), (lx, 400 - ly), 1)
        if y < 0 or y > 400:
            continue

        pygame.draw.line(w, c2, (x, 400 - y), (lx, 400 - ly), 1)

        lx = x
        ly = y

buf = pygame.Surface((400, 400))
buf.blit(w, (0, 0))

font = pygame.font.SysFont(None, 24)

running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    w.blit(buf, (0, 0))

    x, my = pygame.mouse.get_pos()

    y1 = (getPos((x - 200) / g, func)) + 200
    if func2 != "":
        y2 = (getPos((x - 200) / g, func2)) + 200

    if func2 != "":
        if abs((400-y1) - my) < abs((400-y2) - my):


            img = font.render(str((x - 200)/g) + ", " + str(int(y1 - 200)/g), True, (127, 0, 0))
            wi = img.get_size()[0]

            pygame.draw.circle(w, c1, (x, 400 - y1), 10)

            w.blit(img, (x, 400 - y1))
        else:

            img = font.render(str((x - 200)/g) + ", " + str(int(y2 - 200)/g), True, (127, 0, 0))
            wi = img.get_size()[0]

            pygame.draw.circle(w, c2, (x, 400 - y2), 10)

            w.blit(img, (x, 400 - y2))
    else:
        img = font.render(str((x - 200)/g) + ", " + str(int(y1 - 200)/g), True, (127, 0, 0))
        wi = img.get_size()[0]

        pygame.draw.circle(w, c1, (x, 400 - y1), 10)

        w.blit(img, (x, 400 - y1))  
        

    if wi + x > 400:
        x -= wi
    
    pygame.display.flip()
pygame.quit()