import pygame
pygame.init()

w = pygame.display.set_mode((400, 400))
c = pygame.time.Clock()

frames = 0

running = True
while running:
    c.tick(60)
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
    
    mx, my = pygame.mouse.get_pos()

    col = mx/400
    col *= 255

    pygame.display.set_caption(str(frames))

    w.fill((col, col, col))

    keys = pygame.key.get_pressed()

    detail = 10 if keys[pygame.K_SPACE] else 1
    
    for x in range(0, 400, detail):
        for y in range(0, 400, detail):
            r = pygame.Rect(x, y, detail, detail)

            if (((x/detail)%2), ((y/detail)%2)) != (0, 0):
                pygame.draw.rect(w, (255, 0, 0), r)
    
    pygame.display.flip()

    frames += 1
pygame.quit()
