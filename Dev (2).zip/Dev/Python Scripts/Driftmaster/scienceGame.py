import math
import random
from turtle import left
import pygame
pygame.init()

w = pygame.display.set_mode((400, 400))
c = pygame.time.Clock()

class transform:
    def __init__(self, x, y, a):
        self.x = x
        self.y = y
        self.a = a
    
    def move(self, speed):
        self.x += math.cos(self.a * math.pi/180) * speed
        self.y += math.sin(self.a * math.pi/180) * speed

class timer:
    def __init__(self, limit):
        self.limit = limit
        self.timer = 0
    
    def update(self, dt):
        self.timer += dt

        return self.timer > self.limit
    
    def reset(self):
        self.timer = 0

class fruit:
    def __init__(self, lim, numf):
        self.timer = timer(lim)
        self.numf = numf
        self.numfGrown = 0

        self.fp = [(random.randint(-5, 5), random.randint(-5, 5)) for i in range(numf)]

    
    def update(self, dt, transform):
        readyFruit = self.timer.update(dt)

        if readyFruit:
            self.numfGrown += 1 if (self.numfGrown + 1) <= self.numf else 0
            self.timer.reset()

        pygame.draw.circle(w, (0, 255, 0), (transform.x, transform.y), 10)

        for i in range(self.numfGrown):
            pygame.draw.circle(w, (255, 0, 0), (transform.x - self.fp[i][0], transform.y - self.fp[i][1]), 2)
    
    def eat(self):
        self.numfGrown -= 1
        self.timer.reset()


        
class plant:
    def __init__(self, limit, pos=(random.randint(0, 400), random.randint(0, 400))):
        self.transform = transform(pos[0], pos[1], 0)
        self.fruit = fruit(limit, 4)

    def update(self, dt):
        fruit.update(self=self.fruit, dt=dt, transform=self.transform)
    
    def eat(self):
        self.fruit.numfGrown -= 1
        self.fruit.timer.reset()

class predator:
    def __init__(self, vd=400, size=7, wall=0):

        if wall == 0: #left
            x = 0
            y = random.randint(0, 400)
        if wall == 1: #up
            x = random.randint(0, 400)
            y = 0
        if wall == 2: #right
            x = 4000
            y = random.randint(0, 400)
        if wall == 3: #down
            x = random.randint(0, 400)
            y = 400
        self.transform = transform(x, y, 0)
        self.size = size
        self.foodEaten = 0
        self.vd = vd
        self.bestD = vd + 1
        self.s = 6
    
    def update(self, dt, bushes):
        for bush in bushes:
            
            print(math.dist((self.transform.x, self.transform.y), (bush.transform.x, bush.transform.y)) < self.bestD)
            if self.foodEaten < 2 and math.dist((self.transform.x, self.transform.y), (bush.transform.x, bush.transform.y)) < self.bestD:
                
                print(math.dist((self.transform.x, self.transform.y), (bush.transform.x, bush.transform.y)))
                
                angle = math.atan2(bush.transform.y - self.transform.y, bush.transform.x - self.transform.x) * 180 / math.pi

                self.bestD = math.dist((self.transform.x, self.transform.y), (bush.transform.x, bush.transform.y))
                
                self.transform.angle = angle
        
        if self.bestD == self.vd + 1:
            self.transform.a += random.randint(-1, 1)
            print(self.bestD, self.foodEaten)
        
        
        x = math.cos(self.transform.a * math.pi/180) * dt * self.s
        y = math.sin(self.transform.a * math.pi/180) * dt * self.s

        if self.transform.x + x < 400 and self.transform.x + x > 0:
            self.transform.x += x
        if self.transform.y + y < 400 and self.transform.y + y > 0:
            self.transform.y += y

        pygame.draw.circle(w, (127, 0, 0), (self.transform.x, self.transform.y), 7)
        pygame.draw.line(w, (127, 0, 0), (self.transform.x, self.transform.y), (self.transform.x+x, self.transform.y+y), 7)
        

    
    def triggerRange(self, bush):
        return math.dist((self.transform.x, self.transform.y), (bush.transform.x, bush.transform.y)) < self.size + 10
            



bushes = [plant(1000, (random.randint(0, 400), random.randint(0, 400))) for i in range(10)]
predators = [predator(wall=random.randint(0, 3)) for i in range(10)]

running = True
while running:
    c.tick(60)
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        if event.type == pygame.KEYDOWN:
            for bush in bushes:
                for pred in predators:
                    if pred.triggerRange(bush) and pred.foodEaten < 2:
                        bush.eat()
                        pred.foodEaten += 1
    
    w.fill((127, 127, 127))
    
    for bush in bushes:
        bush.update(c.get_time())
    for pred in predators:
        pred.update(c.get_time(), bushes)

    pygame.display.flip()
pygame.quit()
