import math
import pygame
pygame.init()

w = pygame.display.set_mode([400, 400])

x = 10
y = 390

xa = float(input("X acceleration: "))
ya = float(input("y acceleration: "))

xv = xa
yv = ya

grav = 1

running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    w.fill((255, 255, 255))
    
    x += xv
    y += yv

    yv -= grav

    xv *= .99
    yv *= .99

    pygame.draw.circle(w, (0, 0, 0), (x, y), 10)
    pygame.display.flip()
