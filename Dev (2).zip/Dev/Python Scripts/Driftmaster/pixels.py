from math import dist
import random

import pygame
pygame.init()

width = height = 400

w = pygame.display.set_mode([width, height])

strength = 2

threshhold = 255

j = 10

running = True
while running:

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    mx, my = pygame.mouse.get_pos()

    for x in range(0, width, j):
        for y in range(0, height, j):
            v1 = (dist((x, y), (width/4, height/2)) * strength) / (width + height)
            v1 *= 255 + (255 * strength)

            v2 = (dist((x, y), (mx, my)) * strength) / (width + height)
            v2 *= 255 + (255 * strength)

            v3 = (dist((x, y), (width - (width/4), height/2)) * strength) / (width + height)
            v3 *= 255 + (255 * strength)
            
            #ra = random.randint(-25, 25)
            ra = 0

            v = max(min(v1, v2, v3, 255, threshhold), 0)

            r = pygame.Rect(x, y, j, j)

            if v == threshhold:
                v = 255
                pygame.draw.rect(w, (v, v, v), r)
                continue

            v = max(min(v + ra, v + ra, v + ra, 255), 0)
            pygame.draw.rect(w, (v, v, v), r)
    pygame.display.flip()
input()
pygame.quit()