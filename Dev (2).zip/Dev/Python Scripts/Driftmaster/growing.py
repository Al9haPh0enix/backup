## Initialization ##
import math
import random
from turtle import back
import pygame
pygame.init()

## Settings ##
width = 600
height = 600
growCol = (127, 255, 57)
background = (210, 105, 30)
radius = 1

## Cell class ##
class Cell:
    def __init__(self, x, y):
        self.x = x
        self.y = y

## Branch cell class ##
class branch(Cell):
    def __init__(self, angle, radius, ix, iy):
        super().__init__(0, 0)
        self.ix = ix
        self.iy = iy
        self.radius = radius
        self.startAngle = angle
        self.angle = angle
        self.iters = 0
        self.maxIters = random.randint(90, 100)
    def nextIter(self, window):
        self.iters += 1

        if self.iters >= self.maxIters:
            return 1

        self.angle += 15 if random.randint(0, 1) == 1 else -15

        if self.angle < self.startAngle - 20:
            self.angle = self.startAngle - 20
        if self.angle > self.startAngle + 20:
            self.angle = self.startAngle + 20

        self.x += math.cos(self.angle * (math.pi/180)) * self.radius*2
        self.y += math.sin(self.angle * (math.pi/180)) * self.radius*2
        return 0

## Plant cell class ##
class plant(Cell):
    def __init__(self, x, y, radius):
        super().__init__(x, y)
        self.radius = radius
        self.startAngle = 270
        self.angle = 270
        self.branches = [None] * 200
    def nextIter(self, window):
        self.angle += 15 if random.randint(0, 1) == 1 else -15

        
        if self.angle < self.startAngle - 45:
            self.angle = self.startAngle - 45
        if self.angle > self.startAngle + 45:
            self.angle = self.startAngle + 45
        

        if random.randint(0, 10) == 10:
            numAdded = 0
            ind = 0
            for i in self.branches:
                if i == None:
                    self.branches[ind] = branch(self.angle + random.randint(0, 360), self.radius, self.x, self.y)
                    if numAdded == 1:
                        break
                    ind += 1
                    numAdded = 1
                else:
                    ind += 1
                    continue
        ind = 0
        for i in self.branches:
            if i != None:
                if i.nextIter(window):
                    pygame.draw.circle(window, (255, 0, 0), (i.x + i.ix, i.y + i.iy), radius * 5)
                    self.branches[ind] = None
                else:
                    pygame.draw.circle(window, growCol, (i.x + i.ix, i.y + i.iy), radius)  
            ind += 1

        self.x += math.cos(self.angle * (math.pi/180)) * self.radius*2
        self.y += math.sin(self.angle * (math.pi/180)) * self.radius*2
        #self.y -= 1

## Window initialization ##
w = pygame.display.set_mode([width, height])
w.fill(growCol)

## Clock initializations ##
clock = pygame.time.Clock()

p = plant(width/2, height, radius)

## Game Loop ##
running = True
while running:

    ## Clock ##
    clock.tick(60)

    ## Event Loop ##
    for event in pygame.event.get():
        ## Stop when the X is clicked ##
        if event.type == pygame.QUIT:
            running = False

    ## Rendering ##
    #w.fill(background)

    #buf_surf = w.copy()

    #buf_surf.set_alpha(254)

    #w.fill(background)
    #w.blit(buf_surf, (0, 0))

    for i in range(10000):
        p.nextIter(w)

        if p.y <= 0:
            p.y = height
        if p.x < 0:
            p.x = width
        if p.x > width:
            p.x = 0

        pygame.draw.circle(w, growCol, (p.x, p.y), radius)

    pygame.display.flip()

## Close the window ##
pygame.quit()
    