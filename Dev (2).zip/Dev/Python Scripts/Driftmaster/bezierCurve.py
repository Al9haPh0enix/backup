import math
import pygame
pygame.init()

w = pygame.display.set_mode((400, 400))
c = pygame.time.Clock()

def lerp(a, b, t):
    return ((1 - t) * a[0] + t * b[0], (1 - t) * a[1] + t * b[1])


def solve(points, t):
    npoints = []
    bpoints = points

    while len(npoints) != 1:
        npoints = []

        for i in range(len(bpoints)-1):
            npoints.append(lerp(bpoints[i], bpoints[i+1], t))
        bpoints = npoints
    
    return npoints[0]

points = [
    (100, 300),
    (100, 100),
    (300, 100),
    (300, 300),
]

currentDragging = None

running = True
while running:
    mx, my = pygame.mouse.get_pos()

    c.tick(60)
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_r:
                points = [
                    (100, 300),
                    (100, 100),
                    (300, 100),
                    (300, 300),
                ]
        
    
    if pygame.mouse.get_pressed()[0]:  
        ld = math.inf
        ldi = None

        for i in range(len(points)):
            d = math.dist(points[i], (mx, my))

            if d < ld:
                ldi = i
                ld = d
        
        points[ldi] = (mx, my)


    
    if currentDragging != None:
        points[currentDragging] = (mx, my)
    
    w.fill((127, 127, 127))

    t = mx/400

    for i in range(len(points)):
        pygame.draw.circle(w, (255, 0, 0), points[i], 10)
    
    for i in range(500):
        t = i/500
        pygame.draw.circle(w, (255, 127, 127), solve(points, t), 3)

    
    pygame.display.flip()
pygame.quit()
