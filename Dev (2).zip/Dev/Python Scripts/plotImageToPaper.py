import pygame
pygame.init()

im = pygame.image.load("ibm-pc.jpg")

if im.get_width() >= 1280 or im.get_height() >= 720:
    im = pygame.transform.scale(im, (648, 486))

w = pygame.display.set_mode((im.get_width(), im.get_height()))
c = pygame.time.Clock()

pageWidth = 24
pageHeight = 18

running = True
while running:
    c.tick(60)
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
    
    w.fill((127, 0, 127))

    mx, my = pygame.mouse.get_pos()

    w.blit(im, (0, 0))
    
    mx /= im.get_width()
    mx *= pageWidth

    my /= im.get_height()
    my *= pageHeight

    pygame.display.set_caption(str(mx)[0:3+len(str(int(mx)))] + " in, " + str(my)[0:3+len(str(int(mx)))] + " in")
    
    pygame.display.flip()
pygame.quit()
