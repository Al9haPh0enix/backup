print("Joe Mama")







