while True:
    b = float(input("Base: "))
    if b == 123456:
        break
    h = float(input("Height: "))
    if h == 123456:
        break
    
    a = (b * h) / 2

    print(str(a))
