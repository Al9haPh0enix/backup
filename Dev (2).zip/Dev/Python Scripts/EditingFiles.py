#C:\Users\hammersmarkm\Documents\Python Scripts\Names.txt
numOfTimes = int(input("How many names do you want to enter?: "))
for i in range(numOfTimes):
    Fname = input("First Name: ")
    Lname = input("Last Name: ")

    MyFile = open("Names.txt")

    content = MyFile.read()

    MyFile = open("Names.txt", "w")

    MyFile.write(content + Fname + " " + Lname + "\n")

    MyFile = open("Names.txt")

    content = MyFile.read()

    MyFile.close()

    print(Fname + " " + Lname)
MyFile = open("Names.txt")

content = MyFile.read()
print("\n" + content)
