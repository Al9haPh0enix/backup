import requests
while True:
    term = input("Search Term: ")
    
    print("")
    
    url = input("URL: ")
    myobj = {'KEY': 'VALUE'}

    GoodURL = True
    text = ""
    
    try:
        x = requests.post(url, data = myobj)
        text = x.text
    except requests.exceptions.MissingSchema as err:
        print(err)
        GoodURL = False
    except requests.exceptions.ConnectionError as err:
        print("Connection Error - The School Probably Blocked It")
        GoodURL = False

    index = 0
    Index = 0

    word = ""
    wordStart = 0

    if GoodURL:
        print("Good URL")
        termLetters = []
        while index < len(text):
            letter = text[index]
            while Index < len(term):
                Letter = term[Index]
                termLetters.append(Letter)
                Index = index + 1

            for leter in range(len(termLetters)):
                if letter == termLetters[leter]:
                    word += letter
                else:
                    word = ""
            if word == term:
                print("Found word: " + str(index))
            index = index + 1

    
    cont = input("New URL? (y/n): ")

    if cont == "y":
        continue
    else:
        break
