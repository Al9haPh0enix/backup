import math
import pygame
import random

class Particle:

    def __init__(self, x, y):
        self.x = x
        self.y = y

    def update(self, particles):
        down = True
        downLeft = True
        downRight = True
        
        for i in particles:
            if i == type(self):
                if i.x == self.x and i.y == self.y - 1:
                    down = False
                if i.x == self.x - 1 and i.y == self.y - 1:
                    downLeft = False
                if i.x == self.x + 1 and i.y == self.y - 1:
                    downRight = False

        if down and self.y - 1 > 0:
            self.y -= 1
            return 0
        elif downLeft and self.y - 1 > 0:
            self.y -= 1
            self.x -= 1
            return 0
        elif downRight and self.y - 1 > 0:
            self.y -= 1
            self.x +=  1
            return (0)
        return 1

    def show(self, window):
        pygame.draw.circle(window, (255, 0, 0), (self.x + 1, self.y + 1), 3)

pygame.init()

running = True
WIDTH = 150
HEIGHT = 150

screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Water (:")

particles = [[None] * HEIGHT] * WIDTH

for x in range(WIDTH):
    for y in range(HEIGHT):
        particles[x][y] = Particle(x, y)
        if x * y == WIDTH * HEIGHT:
            print("woohoo")
    #print(particles[x][0].x, particles[x][0].y)
print("done")

while running:
    pygame.display.flip()

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    screen.fill((0, 0, 0))

    for x in particles:
        for y in x:
            if type(y) == Particle:
                y.update(particles)
                y.show(screen)
                #print(y.x)
pygame.quit()
