
import random
import pygame
import math

#Line courtesy of Tyler:
#import DEEZ NUTZ

class wall:
    def __init__(self, p1, p2):
        self.p1 = p1
        self.p2 = p2
        self.col = (random.randint(50, 255), random.randint(50, 255), random.randint(50, 255))
        
    def render(self, window, col, col2):
        pygame.draw.line(window, col2, self.p1, self.p2, 7)
        pygame.draw.line(window, col, self.p1, self.p2, 5)

class ray:
    def __init__(self, start, theta, life):
        self.start = start

        #phi =   Phi     left to right
        #theta = Theta   up to down

        theta = theta * (math.pi/180)
        self.theta = theta

        self.life = life
        p2 = ((math.cos(theta) * life) + start[0], (math.sin(theta) * life) + start[1])


        self.p1 = [start[0], start[1]]
        self.p2 = p2
        
    def render(self, window, col):
        pygame.draw.line(window, col, self.p1, self.p2, 2)
    
    def checkInter(self, window, walls):
        smallest = 1000000000
        smallestw = (None, None)
        col = (0, 0, 0)
        for i in walls:
            inter = intersection(i.p1, i.p2, self.p1, self.p2)

            if not inter == False:
                pygame.draw.circle(window, (255, 255, 0), inter, 5)
                if dist(self.start, inter) < smallest and dist(self.start, inter) < self.life:
                    smallest = dist(self.start, inter)
                    smallestw = inter
                    col = i.col
        return [smallestw, smallest, col]

#Two point intersection
def intersection(p1, p2, p3, p4):

    den = (p1[0] - p2[0]) * (p3[1] - p4[1]) - (p1[1] - p2[1]) * (p3[0] - p4[0])
    if den == 0:
        return False

    t = ((p1[0] - p3[0]) * (p3[1] - p4[1]) - (p1[1] - p3[1]) * (p3[0] - p4[0])) / den
    u = -((p1[0] - p2[0]) * (p1[1] - p3[1]) - (p1[1] - p2[1]) * (p1[0] - p3[0])) / den
    if t > 0 and t < 1 and u > 0:
        pt = [0, 0]
        pt[0] = p1[0] + t * (p2[0] - p1[0])
        pt[1] = p1[1] + t * (p2[1] - p1[1])
        return pt
    else:
      return False

def dist(p1, p2):
    return math.sqrt((p2[0] - p1[0])**2 + (p2[1] - p1[1])**2)

#TODO:

"""

1##  ) 3d line intersection                                                             #
2### ) wall height                                                                      #
3##  ) grid instead of columns only                                                     #
4*   ) implement wall height to make 3d render have realistic height (3 needed)          *

"""

"""

import random
import pygame
import math

#Line courtesy of Tyler:
#import DEEZ NUTZ

class wall:
    def __init__(self, p1, p2):
        self.p1 = p1
        self.p2 = p2
        self.col = (random.randint(50, 255), random.randint(50, 255), random.randint(50, 255))
        
    def render(self, window, col, col2):
        pygame.draw.line(window, col2, self.p1[:-1], self.p2[:-1], 7)
        pygame.draw.line(window, col, self.p1[:-1], self.p2[:-1], 5)

class ray:
    def __init__(self, start, phi, theta, life):
        self.start = start

        #phi =   Phi     left to right
        #theta = Theta   up to down

        phi = phi * (math.pi/180)
        self.phi = phi

        theta = theta * (math.pi/180)
        self.theta = theta

        self.life = life
        p2 = (\
            (math.cos(phi) * math.sin(theta)) + start[0],   \
            (math.sin(phi) * math.sin(theta)) + start[1],   \
            (math.cos(theta)) + start[2]   \
                 )

        self.p1 = [start[0], start[1], 0]
        self.p2 = p2
        
    def render(self, window, col):
        pygame.draw.line(window, col, self.p1, self.p2, 2)
    
    def checkInter(self, window, walls):
        smallest = 1000000000
        smallestw = (None, None)
        col = (0, 0, 0)
        for i in walls:
            #wall is just a line not a square so even if the line intersection was working it would only show a line ):
            inter = intersection_3d(i.p1, i.p2, self.p1, self.p2)

            if not inter == False:
                pygame.draw.circle(window, (255, 255, 0), inter[:-1], 5)
                if dist(self.start, inter) < smallest and dist(self.start, inter) < self.life:
                    smallest = dist(self.start, inter)
                    smallestw = inter
                    col = i.col
        return [smallestw, smallest, col]

#Two point intersection
def intersection(p1, p2, p3, p4):

    den = (p1[0] - p2[0]) * (p3[1] - p4[1]) - (p1[1] - p2[1]) * (p3[0] - p4[0])
    if den == 0:
        return False

    t = ((p1[0] - p3[0]) * (p3[1] - p4[1]) - (p1[1] - p3[1]) * (p3[0] - p4[0])) / den
    u = -((p1[0] - p2[0]) * (p1[1] - p3[1]) - (p1[1] - p2[1]) * (p1[0] - p3[0])) / den
    if t > 0 and t < 1 and u > 0:
        pt = [0, 0]
        pt[0] = p1[0] + t * (p2[0] - p1[0])
        pt[1] = p1[1] + t * (p2[1] - p1[1])
        return pt
    else:
      return False

def intersection_3d(p1, p2, p3, p4):
    x1 = p1[0]
    y1 = p1[1]
    z1 = p1[2]

    x2 = p2[0]
    y2 = p2[1]
    z2 = p2[2]

    x3 = p3[0]
    y3 = p3[1]
    z3 = p3[2]
    
    x4 = p4[0]
    y4 = p4[1]
    z4 = p4[2]

    xyinter = intersection([x1, y1], [x2, y2], [x3, y3], [x4, y4])
    xzinter = intersection([x1, z1], [x2, z2], [x3, z3], [x4, z4])

    if xyinter != False:
        if xzinter != False:
            out = [xyinter[0], xyinter[1], xzinter[1]]
            return out
    return False

def dist(p1, p2):
    return math.sqrt((p2[0] - p1[0])**2 + (p2[1] - p1[1])**2 + (p2[2] - p1[2])**2)


1##  ) 3d line intersection                                                             #
2### ) wall height                                                                      #
3##  ) grid instead of columns only                                                     #
4*   ) implement wall height to make 3d render have realistic height (3 needed)          *
"""