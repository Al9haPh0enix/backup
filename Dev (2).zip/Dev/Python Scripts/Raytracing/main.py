
"""
import math
from tracer import wall 
from tracer import intersection
from tracer import ray
from tracer import intersection_3d
import random
import pygame
pygame.init()

def _map(value, leftMin, leftMax, rightMin, rightMax):
    leftSpan = leftMax - leftMin
    rightSpan = rightMax - rightMin
    valueScaled = float(value - leftMin) / float(leftSpan)
    return rightMin + (valueScaled * rightSpan)

width = 800
height = 600

x = 200
y = 200

w = pygame.display.set_mode([width, height])

clock = pygame.time.Clock()

hw = width/2
hh = height/2
pi80 = math.pi/180

a = 90

la = a + 1
lpos = [x, y]
l_ = False

walls = [wall([0, 100, 0], [400, 100, 400]), wall([0, 390, 0], [400, 390, 400])]

_3d_point_1 = [0, 0, 0]
_3d_point_2 = [1, 1, 1]

_3d_point_3 = [1, 0, 0]
_3d_point_4 = [0, 1, 1]

intersection_3d(_3d_point_1, _3d_point_2, _3d_point_3, _3d_point_4)

#for i in range(5):
#    walls[i] = wall([random.randint(0, width), random.randint(0, width), 100], [random.randint(0, width), random.randint(0, width), 100])

running = True
while running:

    delta = clock.tick(60)
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
            
    keys = pygame.key.get_pressed()

    moveSpeed = .05
    turnSpeed = .05
    
    a -= keys[pygame.K_LEFT] * turnSpeed * delta
    a += keys[pygame.K_RIGHT] * turnSpeed * delta

    x += math.cos(a * pi80) * keys[pygame.K_UP] * moveSpeed * delta
    y += math.sin(a * pi80) * keys[pygame.K_UP] * moveSpeed * delta

    x -= math.cos(a * pi80) * keys[pygame.K_DOWN] * moveSpeed * delta
    y -= math.sin(a * pi80) * keys[pygame.K_DOWN] * moveSpeed * delta

    if la == a and lpos == [x, y] and keys[pygame.K_SPACE] == l_:
        continue

    w.fill((0, 0, 0))

    num_rays = 50
    hrays = num_rays/2
    h_rays = height/num_rays
    wrays = width/num_rays

    for i in range(int(-hrays), int(hrays)):
        for z in range(int(-hrays), int(hrays)):
            
            using_ray = ray((x, y, 0), i+a, z, 500)

            intersections = using_ray.checkInter(w, walls)
            distance = intersections[1]
            if distance == (None, None):
                continue
            
            h = _map(distance, 0, 150, 150, 0)

            r = pygame.Rect(  int((z + hrays) * wrays), int((i + hrays) * h_rays), int(wrays), int(h_rays)  )
            pygame.draw.rect(w, intersections[2], r)

    if keys[pygame.K_SPACE]:    
        for i in walls:
            i.render(w, i.col, (0, 0, 0))
            pygame.draw.circle(w, (204, 0, 153), (x, y), 5)
            pygame.draw.line(w, (204, 50, 153), (x, y), (x+(math.cos(a * pi80)*15), y+(math.sin(a * pi80)*15)), 3)

    pygame.display.flip()

    la = a
    lpos = [x, y]
    l_ = keys[pygame.K_SPACE]
"""


import math
from tracer import wall 
from tracer import intersection
from tracer import ray
from tracer import dist
import random
import pygame
pygame.init()

def _map(value, leftMin, leftMax, rightMin, rightMax):
    leftSpan = leftMax - leftMin
    rightSpan = rightMax - rightMin
    valueScaled = float(value - leftMin) / float(leftSpan)
    return rightMin + (valueScaled * rightSpan)

width = 600
height = 600

w = pygame.display.set_mode([width, height])

clock = pygame.time.Clock()

hw = width/2
hh = height/2
pi80 = math.pi/180

x = width - 1
y = height - 1

a = 90

la = a + 1
lpos = [x, y]
l_ = False

walls = [None] * 8

walls[0] = wall( [0, 0], [width, 0] )
walls[1] = wall( [width, 0], [width, height] )
walls[2] = wall( [width, height], [0, height] )
walls[3] = wall( [0, height], [0, 0] )

walls[4] = wall( [50, height], [50, 75] )

walls[5] = wall( [width, 0], [width, height] )
walls[6] = wall( [width, height], [0, height] )
walls[7] = wall( [0, height], [0, 0] )

#for i in range(5):
#    walls[i] = wall([random.randint(0, width), random.randint(0, height)], [random.randint(0, width), random.randint(0, height)])

running = True
while running:

    delta = clock.tick(60)
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
            
    keys = pygame.key.get_pressed()

    moveSpeed = .05
    turnSpeed = .05
    
    a -= keys[pygame.K_LEFT] * turnSpeed * delta
    a += keys[pygame.K_RIGHT] * turnSpeed * delta

    x += math.cos(a * pi80) * keys[pygame.K_UP] * moveSpeed * delta
    y += math.sin(a * pi80) * keys[pygame.K_UP] * moveSpeed * delta

    x -= math.cos(a * pi80) * keys[pygame.K_DOWN] * moveSpeed * delta
    y -= math.sin(a * pi80) * keys[pygame.K_DOWN] * moveSpeed * delta

    if la == a and lpos == [x, y] and keys[pygame.K_SPACE] == l_:
        continue

    w.fill((0, 0, 0))

    num_rays = 50
    hrays = num_rays/2
    wrays = width/num_rays

    for i in range(int(-hrays), int(hrays)):
        using_ray = ray((x, y), i+a, 1000)

        intersections = using_ray.checkInter(w, walls)
        distance = intersections[1]
        
        h = _map(distance, 0, dist([0, 0], [width, height]) + 10, height, 0)

        print(dist([0, 0], [width, height]))

        r = pygame.Rect( i * wrays + hw, hh-(h/2), wrays, h)
        pygame.draw.rect(w, intersections[2], r)

    if keys[pygame.K_SPACE]:    
        for i in walls:
            i.render(w, i.col, (0, 0, 0))
            pygame.draw.circle(w, (204, 0, 153), (x, y), 5)
            pygame.draw.line(w, (204, 50, 153), (x, y), (x+(math.cos(a * pi80)*15), y+(math.sin(a * pi80)*15)), 3)

    pygame.display.flip()

    la = a
    lpos = [x, y]
    l_ = keys[pygame.K_SPACE]