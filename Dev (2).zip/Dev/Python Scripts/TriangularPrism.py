while True:
    TriBase = float(input("TriBase: "))
    TriHeight = float(input("TriHeight: "))

    RecSurf1 = float(input("Rec11: ")) * float(input("Rec12: "))
    RecSurf2 = float(input("Rec21: ")) * float(input("Rec22: "))
    RecSurf3 = float(input("Rec31: ")) * float(input("Rec32: "))
    
    TS = (TriBase * TriHeight) / 2

    out = RecSurf1 + RecSurf2 + RecSurf3 + (TS * 2)

    print(str(out))
