import pygame
pygame.init()

w = pygame.display.set_mode((400, 400))
c = pygame.time.Clock()

running = True
while running:
    c.tick(60)
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
    
    w.fill((127, 127, 127))
    
    for x in range(400):
        if x-1 != 0 and x-2 != 0:
            y = x/(x-1)
            py = (x-1)/(x-2)
            pygame.draw.line(w, (255, 0, 0), (x, y*200), (x-1, py*200), 1)
        
        pygame.draw.line(w, (0, 0, 0), (x-1, (x-1)*200), (x, x*200), 1)
    
    pygame.display.flip()
pygame.quit()
