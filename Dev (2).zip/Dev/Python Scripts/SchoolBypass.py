import requests
#192.168.112.1
while True:
    url = input("URL: ")

    proxies = {'https': 'http://192.168.112.1:1080',}
    myobj = {'KEY': 'VALUE'}

    GoodURL = True
    text = ""
    
    try:
        x = requests.post(url, data = myobj, proxies = proxies)
        text = x.text
    except requests.exceptions.MissingSchema as err: #Error handling
        print(err)
        GoodURL = False
    except requests.exceptions.InvalidURL as err: #Error handling
        print(err)
        GoodURL = False
    except requests.exceptions.InvalidSchema as err: #Error handling
        print(err)
        GoodURL = False
    except requests.exceptions.ConnectionError as err: #Error handling
        print("I failed ):")
        GoodURL = False

    if GoodURL: #Output for good URLs
        cont = input("Good URL! - Continue - Print?: ") 
        
        if cont == "n": #Let the user quit
            break
        elif cont == "print": #Let the user view the data
            print(text)
