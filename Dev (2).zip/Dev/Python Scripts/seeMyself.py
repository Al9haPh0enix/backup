import random
import pygame
pygame.init()

w = pygame.display.set_mode((600, 600))
c = pygame.time.Clock()

def lerp(a, b, k):
    return (b-a) * k + a

pixels = 10

choices = [i for i in range(int((w.get_width()/pixels)*(w.get_height()/pixels)))]
bgCol = [random.randint(0, 255) for i in range(3)]

w.fill(bgCol)

variance = 20

colArr = [[[0 for i in range(3)] for i in range(int(w.get_height()/pixels))] for i in range(int(w.get_width()/pixels))]

averaging = False

indX = 0
indY = 0

avg = [0, 0, 0]
avgIters = 0

running = True
while running:
    c.tick(60)
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
            running = False
    if averaging:
        for i in range(int((w.get_width()*w.get_height())/16000)):

            avg[0] += colArr[indX][indY][0]
            avg[1] += colArr[indX][indY][1]
            avg[2] += colArr[indX][indY][2]

            avgIters += 1
            indX += 1
            if indX >= len(colArr):
                indX = 0
                indY += 1
                if indY >= len(colArr[0]):
                    indY = 0
                    averaging = False
                    colArr = [[[0 for i in range(3)] for i in range(int(w.get_height()/pixels))] for i in range(int(w.get_width()/pixels))]
                    bgCol = [i/avgIters for i in avg]
                    w.fill(bgCol)
                    avg = [0, 0, 0]
                    avgIters = 0
                    break
            w.fill([i/avgIters for i in avg])
    else:
        for i in range(int((w.get_width()*w.get_height())/16000)):
            if len(choices) > 0:
                chI = random.randint(0, len(choices)-1)
                ch = choices[chI]
                r = pygame.Rect((ch*pixels)%w.get_width(), int((ch*pixels)/(w.get_width()/pixels)), pixels, pixels)

                choices.pop(chI)
                
                colChange = random.randint(-variance, variance)

                nCol = [min(255, max(0, i + lerp(colChange, colChange*2, bgCol.index(i)/3))) for i in bgCol]

                colArr[int(((ch*pixels)%w.get_width())/pixels)][int(int((ch*pixels)/(w.get_width()/pixels))/pixels)] = nCol

                pygame.draw.rect(w, nCol, r)
            else:
                choices = [i for i in range(int((w.get_width()/pixels)*(w.get_height()/pixels)))]
                w.fill(bgCol)
                mx, my = pygame.mouse.get_pos()
                variance = int((mx/w.get_width())*255)
                pygame.display.set_caption(str(variance))
                averaging = True
    pygame.display.flip()
pygame.quit()
