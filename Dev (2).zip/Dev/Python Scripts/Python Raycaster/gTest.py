import pygame
pygame.init()

w = pygame.display.set_mode([512, 512])

rect_surf = pygame.Surface((100, 200))
rect_surf.fill((127, 127, 127))

a = 1

running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
    w.fill((0, 0, 0))

    pos = (rect_surf.get_width()//2, rect_surf.get_height()//2) 
    originPos = rect_surf.get_rect().center
    
    image_rect = rect_surf.get_rect(topleft = (pos[0] - originPos[0], pos[1]-originPos[1]))
    offset_center_to_pivot = pygame.math.Vector2(pos) - image_rect.center
    rotated_offset = offset_center_to_pivot.rotate(-a)
    rotated_image_center = (pos[0] - rotated_offset.x, pos[1] - rotated_offset.y)

    # get a rotated image
    rotated_image = pygame.transform.rotate(rect_surf, a)
    rotated_image_rect = rotated_image.get_rect(center = rotated_image_center)
    origin = rotated_image_rect.topleft

    rotated_image = pygame.transform.rotate(rect_surf, a)

    w.blit(rotated_image, origin)

    a += 1

    pygame.display.flip()
pygame.quit()