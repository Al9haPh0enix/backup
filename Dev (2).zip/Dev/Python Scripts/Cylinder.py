pi = 3.14

r = float(input("Radius: "))
h = float(input("Height: "))
pi314 = input("3.14 | pi: ")
a = 0

if pi314 == "3.14":
    c = 3.14 * (r * 2)

    a = (pi * ((r * r) * 2)) + (h * c)
if pi314 == "pi":
    c = 3.14 * (r * 2)

    a = (pi * ((r * r) * 2)) + (h * c)

    a /= 3.14

print(str(a))


