import pygame
pygame.init()

def lerp(v0, v1, t):
    return (1 - t) * v0 + t * v1

def lerp2(p0, p1, t):
    return (lerp(p0[0], p1[0], t), lerp(p0[1], p1[1], t))


w = pygame.display.set_mode((400, 400))
c = pygame.time.Clock()

p1 = (100, 100)
p2 = (200, 300)
p3 = (300, 100)

running = True
while running:
    c.tick(60)
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
    
    w.fill((127, 127, 127))

    mx, my = pygame.mouse.get_pos()

    t = mx/400

    pygame.draw.circle(w, (255, 0, 0), p1, 5)
    pygame.draw.circle(w, (255, 0, 0), p2, 5)
    pygame.draw.circle(w, (255, 0, 0), p3, 5)
    
    pygame.draw.line(w, (255, 0, 0), p1, p2, 2)
    pygame.draw.line(w, (255, 0, 0), p2, p3, 2)

    pygame.draw.line(w, (255, 255, 255), lerp2(p1, p2, t), lerp2(p2, p3, t), 3)

    pygame.draw.circle(w, (255, 0, 0), lerp2(lerp2(p1, p2, t), lerp2(p2, p3, t), t), 5)
    
    pygame.display.flip()
pygame.quit()
