def f(x):
    return -(x*x) - (3*x)

while True:
    x_str = input("x: ")
    
    if x_str == "done":
        break
    
    x = int(x_str)
    
    print( f(x) )
