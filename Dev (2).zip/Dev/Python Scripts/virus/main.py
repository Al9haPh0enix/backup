print("test")

for i in range(3):
    print(i + 1)