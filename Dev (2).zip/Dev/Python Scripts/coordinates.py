
import pygame
import random


WIDTH = 400
HEIGHT = 400

# Define Colors 
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
RED = (255, 0, 0)
GREEN = (0, 255, 0)
BLUE = (0, 0, 255)

pygame.init()
screen = pygame.display.set_mode((WIDTH, HEIGHT))

running = True
while running:

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
    screen.fill(BLACK)
    
    for x in range(WIDTH):
        for y in range(HEIGHT):
            pos = (x, y)
            r = int((y / HEIGHT) * 255)
            g = int((x / WIDTH) * 255)
            b = random.randint(0, 255)
            pygame.draw.circle(screen, (r, g, b), pos, 1)
    pygame.display.flip()
pygame.quit()
