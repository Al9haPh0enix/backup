import pygame
import math
pygame.init()

w = pygame.display.set_mode([400, 400])

x = 200
y = 200

vx = 0
vy = 0

plf = False

running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
    w.fill((255, 255, 255))

    keys = pygame.key.get_pressed()
    mx, my = pygame.mouse.get_pos()
    rmx, rmy = pygame.mouse.get_rel()

    if keys[pygame.K_SPACE] and math.dist((x, y), (mx, my)) < 20 + max(abs(rmx), abs(rmy)):
        if not plf:
            offx = x - mx
            offy = y - my
        x = mx + offx
        y = my + offy
        plf = True
        vx = rmx
        vy = rmy
    else:
        offx = 0
        plf = False
        if x + vx > 400 or x + vx < 0:
            vx *= -.5
        if y + vy > 400 or y + vy < 0:
            vy *= -.5
        x += vx
        y += vy
        vx *= .99
        vy *= .99

    pygame.draw.circle(w, (0, 0, 0), (x, y), 20)
    pygame.display.flip()
pygame.quit()