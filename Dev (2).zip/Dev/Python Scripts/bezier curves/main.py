
import math
import pygame
pygame.init()

window = pygame.display.set_mode([400, 400])
mousePosX = 0
mousePosY = 0
xnew = 0
ynew = 0 

#Function to draw all other 7 pixels present at symmetric position
def drawCircle(xc, yc, x, y, c):
	pygame.draw.rect(window, c, pygame.Rect(xc+x,yc+y, 1, 1))
	pygame.draw.rect(window, c, pygame.Rect(xc-x,yc+y, 1, 1))
	pygame.draw.rect(window, c, pygame.Rect(xc+x,yc-y, 1, 1))
	pygame.draw.rect(window, c, pygame.Rect(xc-x,yc-y, 1, 1))
	pygame.draw.rect(window, c, pygame.Rect(xc+y,yc+x, 1, 1))
	pygame.draw.rect(window, c, pygame.Rect(xc-y,yc+x, 1, 1))
	pygame.draw.rect(window, c, pygame.Rect(xc+y,yc-x, 1, 1))
	pygame.draw.rect(window, c, pygame.Rect(xc-y,yc-x, 1, 1))


#Function for circle-generation using Bresenham's algorithm
def circleBres(xc, yc, r, c):
	x = 0
	y = r
	d = 3 - 2 * r
	while (y >= x):
		#for each pixel we will draw all eight pixels
		drawCircle(xc, yc, x, y, c)
		x += 1

		#check for decision parameter and correspondingly update d, x, y
		if (d > 0):
			y -= 1
			d = d + 4 * (x - y) + 10
		
		else:
			d = d + 4 * x + 6
		drawCircle(xc, yc, x, y, c)
	


# Function that take input as Control Pox_coordinates and
#Control Poy_coordinates and draw bezier curve
def bezierCurve(x, y, c):
	xu = 0.0
	yu = 0.0
	u = 0.0 
	i = 0
	u = 0.0
	while(u <= 1.0):
		xu = pow(1-u,3)*x[0]+3*u*pow(1-u,2)*x[1]+3*pow(u,2)*(1-u)*x[2]+pow(u,3)*x[3]
		yu = pow(1-u,3)*y[0]+3*u*pow(1-u,2)*y[1]+3*pow(u,2)*(1-u)*y[2]+pow(u,3)*y[3]
		pygame.draw.circle(window, c, (xu, yu), 1)
		u += 0.0001
	

done = False

i = 0 
x = [200, 300, 400, 200]
y = [100, 200, 300, 300]
flagDrawn = 0 

while (not done):

	#set background color to black
	window.fill((0, 0, 0))

	#set draw color to white

	# We are drawing cubic bezier curve which has four control points
	if(i==4):
		bezierCurve(x , y, (200, 100, 150)) 
		flagDrawn = 1 
	

	#grey color circle to encircle control PoP0
	print(x[0])
	pygame.draw.circle(window, (128, 128, 128), (x[0] , y[0]) , 8) 

	#Red Line between control PoP0 & P1
	pygame.draw.line(window, (255, 0, 0), (x[0] , y[0]) , (x[1] , y[1]), 1) 

	#grey color circle to encircle control PoP1
	pygame.draw.circle(window, (128, 128, 128), (x[1] , y[1]) , 8) 

	#Red Line between control PoP1 & P2
	pygame.draw.line(window, (255, 0, 0), (x[1] , y[1]) , (x[2] , y[2])) 

	#grey color circle to encircle control PoP2
	pygame.draw.circle(window, (128, 128, 128), (x[2] , y[2]) , 8) 

	#Red Line between control PoP2 & P3
	pygame.draw.line(window, (255, 0, 0) , (x[2] , y[2]) , (x[3] , y[3])) 

	#grey color circle to encircle control PoP3
	pygame.draw.circle(window, (128, 128, 128), (x[3] , y[3]) , 8) 

	for event in pygame.event.get():
		# if window cross button clicked then quit from window
		if (event.type == pygame.QUIT):
			done = True
		
		#Mouse Button is Down
		if(event.type == pygame.MOUSEBUTTONDOWN):
			#If left mouse button down then store that poas control point
			if(pygame.mouse.get_pressed()[0]):
				#store only four points because of cubic bezier curve
				if(i < 4):
					print("Control Point(P%d):(%d,%d)\n",i,mousePosX,mousePosY) 

					#Storing Mouse x and y positions in our x and y coordinate array
					x[i] = mousePosX 
					y[i] = mousePosY 
					i += 1
				
			
		
		#Mouse is in motion
		if(pygame.mouse.get_rel() != (0, 0)):
			#get x and y positions from motion of mouse
			xnew, ynew = pygame.mouse.get_pos()

			

			# change coordinates of control point after bezier curve has been drawn
			if(flagDrawn == 1):
				for j in range(i):
					#Check mouse position if in b/w circle then change position of that control poto mouse new position which are coming from mouse motion
					if(math.sqrt(abs(xnew-x[j]) * abs(xnew-x[j]) + abs(ynew-y[j]) * abs(ynew-y[j])) < 8.0):
						#change coordinate of jth control point
						x[j] = xnew 
						y[j] = ynew 
						print("Changed Control Point(P%d):(%d,%d)\n",j,xnew,ynew) 
					
				
			
			#updating mouse positions to positions coming from motion*/
			mousePosX = xnew 
			mousePosY = ynew 
		
	
	#show the window*
	pygame.display.flip()

