import pygame
pygame.init()

class Object:
    def __init__(self, x=0, y=0):
        self.x = x
        self.y = y

        self.lx = x
        self.ly = y

        self.accx = 0
        self.accy = 0
    
    def updatePosition(self, dt: float):
        npx = (2*self.x)-self.lx+(self.accx*self.x)*dt*dt
        npy = (2*self.y)-self.ly+(self.accy*self.y)*dt*dt

        self.lx = self.x
        self.ly = self.y

        self.x = npx
        self.y = npy

    def accelerate(self, accx, accy):
        self.accx += accx
        self.accy += accy

w = pygame.display.set_mode((400, 400))
c = pygame.time.Clock()

o = Object(200, 200)

running = True
while running:
    c.tick(60)
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        if event.type == pygame.KEYDOWN:
            o.accelerate(int(input("x: ")), int(input("y: ")))
    
    w.fill((127, 127, 127))
    
    pygame.draw.circle(w, (0, 0, 0), (o.x, o.y), 20)


    
    pygame.display.flip()
pygame.quit()
