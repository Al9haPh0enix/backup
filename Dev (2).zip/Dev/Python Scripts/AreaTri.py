while True:
    a = float(input("A: "))
    b = float(input("B: "))

    num = (a*b)/2

    print(str(num))

    cont = input("continue? (y/n)")

    if cont == "n":
        break


