import time
import math

def calc(iterations):
    
    print("calculating...")
    
    plus = 1
    out = 0

    for i in range(1, iterations, 2):
        out += plus/i
        plus = -plus
    
    return out, iterations

start = time.time()
out, iterations = calc(int(input("Iterations: ")))
end = time.time()

buf = 0
iteration_num = 0

pi = ""

for i in str(out*4):
    try:
        if i == '.':
            continue
        if i == str(math.pi)[iteration_num]:
            buf += 1
        else:
            break
    except:
        break
    pi += i
    iteration_num += 1

print()
print(str(pi) + " : " + str(math.pi))
print("It got " + str(buf) + " numbers correct.")

#best out at 1 billion iterations V
"""
calculating...

3.141592651589258 : 3.141592653589793
It got 9 numbers correct at 100.4700231552124 seconds and 1000000000 iterations!
"""
