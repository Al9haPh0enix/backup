import random

while True:
    file = open("Quotes.txt")
    content = file.readlines()
    choice = input("Read or Write: ")

    if choice == "Read":
        print(content[random.randint(0, len(content) - 1)])

    if choice == "Write":
        wrt = input("Quote: ")
        
        file = open("Quotes.txt")
        content = file.read()
        
        file = open("Quotes.txt", "w")
        file.write(content + wrt + "\n")
        
