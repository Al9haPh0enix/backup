
import math
import pygame
import pygame.freetype
import random
pygame.init()

def getAngle(x1, y1, x2, y2):
    return math.atan2(y2 - y1, x2 - x1) * 180 / math.pi
def dist(x1, y1, x2, y2):
    return ((x1 - x2)**2 + (y1 - y2)**2)**0.5
def mag(x, y):
    return math.sqrt((x*x)+(y*y))
def renderTo(s, font, color, pos, text, size):
    font.fgcolor = color
    font.size = size
    
    r = font.get_rect(text)
    font.render_to(s, (pos[0] - r.width/2, pos[1] - r.height/2), text)
def renderToLeft(s, font, color, pos, text, size):
    font.fgcolor = color
    font.size = size
    
    r = font.get_rect(text)
    font.render_to(s, (pos[0], pos[1] - r.height/2), text)

class weaponType:
    def __init__(self, pierce, fireSpeed, bulletSize, recoil, ammoUsage, damage, spread, Langle=0, Mangle=1, increment = 10):
        self.pierce = pierce - 1
        self.fireSpeed = fireSpeed
        self.bulletSize = bulletSize
        self.ammoUsage = ammoUsage
        self.spread = spread
        self.Langle = Langle
        self.Mangle = Mangle
        self.increment = increment
        self.damage = damage
        self.recoil = recoil
    
    def genBullets(self, px, py, angle):
        bulets = []
        if self.Langle == None:
            ra = random.randint(-self.spread, self.spread)
            bulets.append([px, py, math.cos((angle + ra) * math.pi/180), math.sin((angle + ra) * math.pi/180), 0, self.pierce]) # x, y, xadd, yadd, radius, enemies pierced, pierce level, damage
        else:
            rea = random.randint(-self.spread, self.spread)
            for a in range(self.Langle, self.Mangle, self.increment):
                ra = random.randint(-self.spread, self.spread)
                bulets.append([px, py, math.cos(((angle+a) + ra) * math.pi/180), math.sin(((angle+a) + ra) * math.pi/180), self.bulletSize, 0, self.pierce, self.damage]) # x, y, xadd, yadd, radius, enemies pierced, pierce level, damage
        return bulets

class enemyType:
    def __init__(self, distribution, size, health, speed, score, color):
        self.distribution = distribution
        self.health = health
        self.speed = speed
        self.score = score
        self.size = size
        self.color = color

class boostType:
    def __init__(self, speed,  damage,  firerate,  ammoUsed,  expirationTime):
        self.speed = speed
        self.damage = damage
        self.firerate = firerate
        self.ammoUsed = ammoUsed
        self.expirationTime = expirationTime


font = pygame.freetype.Font("BlackOpsOne-Regular.ttf", 10)

ammoIcon = pygame.image.load("ammoIcon.png")
ammoIcon = pygame.transform.scale(ammoIcon, (30, 30))

respawnRect = pygame.Rect(250, 300, 100, 50)

def updateUI(uiS, ammo, score, highScore, weapon):
    uiS.fill((0, 0, 0))

    renderToLeft(uiS, font, (255, 255, 255), (50, 575), "Ammo: " + str(ammo), 15)
    renderTo(uiS, font, (255, 255, 255), (525, 575), "Score: " + str(score), 15)
    renderTo(uiS, font, (255, 255, 255), (525, 550), "Highscore: " + str(highScore), 15)
    renderToLeft(uiS, font, (255, 255, 255), (15 ,  15), weapon, 15)

    uiS.blit(ammoIcon, (15, 560))

w = pygame.display.set_mode([600, 600])
c = pygame.time.Clock()

uiS = pygame.Surface([600,600])

enemies = []
bullets = []

with open("hs.txt") as f:
    lines = [i.strip() for i in f.readlines()]

if len(lines) == 0:
    hs = 0
else:
    hs = int(lines[0][0:10])

bulSpeed = 250
numEn = 5
moveSpeed = 25
maxSpeed = 4
slowDown = .8
speedDampening = 2
enr = 10
respawnSpeed = 250
pr = 6
deathSafety = 1
killHelp = 1

gunTypes = {
    "Pistol" :           weaponType(pierce=1,   fireSpeed=250,   bulletSize=3,   recoil = 1,   ammoUsage=0,   damage = 1, spread = 5),
    "Shotgun" :          weaponType(pierce=1,   fireSpeed=500,   bulletSize=3,   recoil = 3,   ammoUsage=2,   damage = 1, spread = 10, Langle=-20,  Mangle=20,  increment=10),
    "AK" :               weaponType(pierce=1,   fireSpeed=100,   bulletSize=2,   recoil = 1,   ammoUsage=1,   damage = 1, spread = 10),
    "Cannon" :           weaponType(pierce=4,   fireSpeed=1000,  bulletSize=15,  recoil = 5,   ammoUsage=4,   damage = 2, spread = 2),
    "Sniper" :           weaponType(pierce=30,  fireSpeed=500,   bulletSize=4,   recoil = 5,   ammoUsage=2,   damage = 3, spread = 0)
}

enemyTypes = {
    "Reddie" :           enemyType( distribution=8, size=10, health=1, speed=1,    score=1, color=(255, 0, 0)   ),
    "Giant" :            enemyType( distribution=1, size=10, health=2, speed=.5,   score=2, color=(255, 255, 0) ),
    "Scout" :            enemyType( distribution=1, size=10, health=1, speed=1.5,  score=2, color=(0, 255, 200) )
}

boostTypes = {
    "" :                 boostType(speed=1,  damage=1,  firerate=1,   ammoUsed=True,   expirationTime=9999999999999999),
    "Speed" :            boostType(speed=2,  damage=1,  firerate=1,   ammoUsed=True,   expirationTime=1000),
    "Damage" :           boostType(speed=1,  damage=1,  firerate=1,   ammoUsed=True,   expirationTime=1000),
    "Gunup" :            boostType(speed=1,  damage=1,  firerate=50,  ammoUsed=False,  expirationTime=1000)
}

with open("hs.txt", "w") as f:
    f.write(" " * (10-len(str(hs))) + str(hs))

    while True:

        px, py = 300, 300
        xv, yv = 0, 0

        enemies = []
        bullets = []    

        weaponT = "Pistol"
        boostT = ""
        timeSinceBoostGained=0

        angle = 0

        lt = 0
        time = 0
        rtime = 0

        score = 0

        ammo = 50

        enemyKill = None

        running = True
        while running:
            dt = c.tick(60)/1000
            time += dt*1000
            rtime += dt*1000
            timeSinceBoostGained += dt*1000

            if boostTypes[boostT].expirationTime <= timeSinceBoostGained:
                boostT = ""

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False

                if event.type == pygame.KEYDOWN:
                    
                    if event.key == pygame.K_1:
                        weaponT = (list(gunTypes.keys())[0])
                    if event.key == pygame.K_2:
                        weaponT = (list(gunTypes.keys())[1])
                    if event.key == pygame.K_3:
                        weaponT = (list(gunTypes.keys())[2])
                    if event.key == pygame.K_4:
                        weaponT = (list(gunTypes.keys())[3])
                    if event.key == pygame.K_5:
                        weaponT = (list(gunTypes.keys())[4])
                        """
                    if event.key == pygame.K_6:
                        weaponT = (list(gunTypes.keys())[5])
                    if event.key == pygame.K_7:
                        weaponT = (list(gunTypes.keys())[6])
                    if event.key == pygame.K_8:
                        weaponT = (list(gunTypes.keys())[7])
                    if event.key == pygame.K_9:
                        weaponT = (list(gunTypes.keys())[8])
                    if event.key == pygame.K_0:
                        weaponT = (list(gunTypes.keys())[9])
                        """
                   
                    if event.key == pygame.K_ESCAPE:
                        running = False
                    
                    if event.key == pygame.K_e:
                        boostT = "Speed"
                        timeSinceBoostGained = 0
            
            if len(enemies) < numEn and int(rtime) > respawnSpeed:

                choices = []
                for i in enemyTypes:
                    for j in range(enemyTypes[i].distribution):
                        choices.append(i)

                choice = random.choice(choices)

                enemies.append(random.choice([[random.randint(0, 600), 0], [random.randint(0, 600), 600], [0, random.randint(0, 600)], [600, random.randint(0, 600)]]) + [enemyTypes[choice].health, enemyTypes[choice].size, enemyTypes[choice].speed, enemyTypes[choice].score, enemyTypes[choice].color]) #x, y, health, size, speed
                
                rtime = 0
            
            mx, my = pygame.mouse.get_pos()
            keys = pygame.key.get_pressed()
            
            if keys[pygame.K_w]:
                yv -= (moveSpeed * (1+boostTypes[boostT].speed)) * dt
            if keys[pygame.K_a]:
                xv -= (moveSpeed * (1+boostTypes[boostT].speed)) * dt
            if keys[pygame.K_s]:
                yv += (moveSpeed * (1+boostTypes[boostT].speed)) * dt
            if keys[pygame.K_d]:
                xv += (moveSpeed * (1+boostTypes[boostT].speed)) * dt
            
            if xv > maxSpeed + boostTypes[boostT].speed:
                xv = maxSpeed + boostTypes[boostT].speed
            if yv > maxSpeed + boostTypes[boostT].speed:
                yv = maxSpeed + boostTypes[boostT].speed
            
            if xv < -(maxSpeed + boostTypes[boostT].speed):
                xv = -(maxSpeed + boostTypes[boostT].speed)
            if yv < -(maxSpeed + boostTypes[boostT].speed):
                yv = -(maxSpeed + boostTypes[boostT].speed)

            if keys[pygame.K_SPACE]:
                if time > gunTypes[weaponT].fireSpeed:
                    [bullets.append(i) for i in gunTypes[weaponT].genBullets(px, py, angle)] # x, y, xadd, yadd, radius, enemies pierced, pierce level, damage
                    ammo -= gunTypes[weaponT].ammoUsage

                    xv -= math.cos(angle * math.pi/180) * gunTypes[weaponT].recoil * (1/slowDown)
                    yv -= math.sin(angle * math.pi/180) * gunTypes[weaponT].recoil * (1/slowDown)
                                        
                    time = 0 
            
            if px + xv > 0 and px + xv < 600:
                px += xv
            else:
                xv = 0
            if py + yv > 0 and py + yv < 600:
                py += yv
            else:
                yv = 0
            
            xv *= slowDown
            yv *= slowDown

            
            w.fill((0, 0, 0))
            
            angle = getAngle(px, py, mx, my)
            
            pointx = math.cos(angle * (math.pi/180)) * 15
            pointy = math.sin(angle * (math.pi/180)) * 15
            
            pygame.draw.circle(w, (255, 255, 255), (px, py), pr)
            pygame.draw.line(w, (255, 0, 0), (px, py), (pointx + px, pointy + py), 2)
            
            for eni in range(len(enemies)):
                
                a = getAngle(px, py, enemies[eni][0], enemies[eni][1])
                
                xa = math.cos(a * math.pi/180) * enemies[eni][4]
                ya = math.sin(a * math.pi/180) * enemies[eni][4]
                
                enemies[eni][0] = enemies[eni][0] - xa
                enemies[eni][1] = enemies[eni][1] - ya
                
                pygame.draw.circle(w, enemies[eni][6], enemies[eni][0:2], enemies[eni][3])
                
                if dist(px, py, enemies[eni][0], enemies[eni][1]) < (enemies[eni][3] + pr) - deathSafety:
                    enemyKill = enemies[eni][0:2]
                    running = False
                    through = False

                    if score > hs:
                        hs = score
                        f.seek(0)
                        f.write(" " * (10 - len(str(hs))) + str(hs))

                    break
            
            restarting = True
            while restarting:

                through = True
                for buli in range(len(bullets)):
                    bul = bullets[buli]
                    bx, by = bul[0:2]
                    
                    bullets[buli][0] += (bul[2] * bulSpeed * dt)
                    bullets[buli][1] += (bul[3] * bulSpeed * dt)

                    pygame.draw.circle(w, (255, 255, 0), (bx, by), bul[4])
                    
                    if bx > 600 or bx < 0 or by > 600 or by < 0:
                        bullets.pop(buli)
                        through = False

                    else:
                        for eni in range(len(enemies)):
                            en = enemies[eni]

                            d = dist(en[0], en[1], bx, by)
                            if d < (enemies[eni][3]+bul[4]) + killHelp:
                                score += enemies[eni][5]

                                pygame.draw.circle(w, (0, 0, 0), enemies[eni][0:2], enemies[eni][3])
                                
                                ammo += 1

                                enemies[eni][2] -= 1

                                if enemies[eni][2] <= 0:
                                    enemies.pop(eni)

                                if bullets[buli][5] < bullets[buli][6]: # x, y, xadd, yadd, radius, enemies pierced, pierce level, damage
                                    bullets[buli][5] += 1
                                else:
                                    bullets.pop(buli)
                                through = False
                                break
                    if not through:
                        break
                            
                if through:
                    restarting = False

            updateUI(uiS, ammo, score, hs, weaponT)
            uiS.set_colorkey((0,0,0))
            w.blit(uiS, (0, 0))

            pygame.display.flip()
        
        respawn = False

        running = enemyKill != None
        while running:

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False

            w.fill((0, 0, 0))
                
            angle = getAngle(px, py, mx, my)
                
            pointx = math.cos(angle * (math.pi/180)) * 15
            pointy = math.sin(angle * (math.pi/180)) * 15
                
            pygame.draw.circle(w, (255, 255, 255), (px, py), pr)
            pygame.draw.line(w, (255, 0, 0), (px, py), (pointx + px, pointy + py), 2)

            pygame.draw.circle(w, (255, 255, 0), enemyKill, enr)

            renderTo(w, font, (127, 127, 127), (300, 175), "You Were Lost", 50)
            renderTo(w, font, (127, 127, 127), (300, 225), "Score: " + str(score), 50)

            x, y = pygame.mouse.get_pos()

            pygame.draw.rect(w, (255, 255, 255), respawnRect)
            renderTo(w, font, (0, 0, 0), (respawnRect.x + (respawnRect.width/2), respawnRect.y + (respawnRect.height/2)), "Respawn", min(respawnRect.width, respawnRect.height)/3)

            if x > respawnRect.x and x < respawnRect.x + respawnRect.width and y > respawnRect.y and y < respawnRect.y + respawnRect.height:
                if pygame.mouse.get_pressed()[0]:
                    respawn = True
                    break

            pygame.display.flip()
        if not respawn:
            break
pygame.quit()