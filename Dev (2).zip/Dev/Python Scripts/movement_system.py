class PVector:
  def __init__(self, x, y):
    self.x = x
    self.y = y

import pygame

keys = [True, False, True, False]

position = PVector(0, 0)

angle = 0
speed = 0
radius = 25

def setup():
  background(0)

def draw():
  background(0, 0, 0)
  stroke(255)
  noFill()
  
  speed = 0
  if keyPressed:
    if keys[0] :
      speed = 4
    
    
    if(keys[1]) :
      angle -= 4
    
    
    if(keys[2]) :
      angle += 4
    
    
    if(keys[3]) :
      speed = -4
    
  
  
  if(position.x + cos(radians(angle)) * speed > (width / 2) - (radius / 2) or position.x + cos(radians(angle)) * speed < -(width / 2) + (radius / 2)):
    pass
  else:
    position.x += cos(radians(angle)) * speed
  
  
  #position.y + sin(radians(angle)) * speed < -(height / 2) + (radius / 2)
  
  if(position.y + sin(radians(angle)) * speed > (height / 2) - (radius / 2) or position.y + sin(radians(angle)) * speed < -(height / 2) + (radius / 2)):
    pass
  else:
    position.y += sin(radians(angle)) * speed
  
  
  ellipse(position.x, position.y, radius, radius)
  fill(255)
  ellipse((cos(radians(angle)) * (radius / 2)) + position.x, (sin(radians(angle)) * (radius / 2)) + position.y, radius / 3, radius / 3)
  #stroke((sin(radians(angle)) + 1)  * (radius5 / 2), (cos(radians(angle)) + 1)  * (radius5 / 2), (cos(radians(angle + 90)) + 1)  * (radius5 / 2))
  #fill((sin(radians(angle)) + 1)  * (radius5 / 2), (cos(radians(angle)) + 1)  * (radius5 / 2), (cos(radians(angle + 90)) + 1)  * (radius5 / 2))
  #circle(position.x, position.y, 5)
  
  line((width / 2) - (radius / 2), height / 2 - (radius / 2), -(width / 2) + (radius / 2), height / 2 - (radius / 2))
  line((width / 2) - (radius / 2), -height / 2 + (radius / 2), -(width / 2) + (radius / 2), -height / 2 + (radius / 2))
  
  line(width / 2 - (radius / 2), height / 2 - (radius / 2), width / 2 - (radius / 2), -height / 2 + (radius / 2))
  line(-width / 2 + (radius / 2), height / 2 - (radius / 2), -width / 2 + (radius / 2), -height / 2 + (radius / 2))
  
  
  line((width / 2) - (radius), height / 2 - (radius), -(width / 2) + (radius), height / 2 - (radius))
  line((width / 2) - (radius), -height / 2 + (radius), -(width / 2) + (radius), -height / 2 + (radius))
  
  line(width / 2 - (radius), height / 2 - (radius), width / 2 - (radius), -height / 2 + (radius))
  line(-width / 2 + (radius), height / 2 - (radius), -width / 2 + (radius), -height / 2 + (radius))


def keyPressed() :
  if (key == 'w'):  keys[0] = true
  if (key == 'a'):  keys[1] = true
  if (key == 'd'):  keys[2] = true
  if (key == 's'):  keys[3] = true


def keyReleased() :
  if (key == 'w'):  keys[0] = false
  if (key == 'a'):  keys[1] = false
  if (key == 'd'):  keys[2] = false
  if (key == 's'):  keys[3] = false

