
a = int(input("a: "))
b = int(input("b: "))
c = int(input("c: "))

x = -b/(2*a)


print("Axis of Symmetry: x =", x)
print("Vertex: (" + str(x) + ", " + str( (a * (x * x)) + (b * x) + c ) + ")")