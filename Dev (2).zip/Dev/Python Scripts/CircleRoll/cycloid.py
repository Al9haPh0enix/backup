
import pygame
import math
pygame.init()

w = pygame.display.set_mode((400, 400))
c = pygame.time.Clock()

posl = []

d = 30
rollSpeed = 2

an = 0
a = 0

x = 0
y = 200

anim = False

running = True
while running:
    c.tick(60)
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        
        if event.type == pygame.KEYDOWN and event.key == pygame.K_SPACE and not anim:
            posl = []
            x = 0
            a = 0
            anim = True
        elif event.type == pygame.KEYDOWN and event.key == pygame.K_SPACE:
            anim = False
    
    w.fill((127, 127, 127))

    if anim:
        a += rollSpeed * math.pi/180
        x1 = math.cos(a) * d
        y1 = math.sin(a) * d
            
        #pygame.draw.circle(w, (0, 255, 0), (x, y), d)
        #pygame.draw.circle(w, (0, 0, 255), (200 + x3, 200 + y3), c3s * scale)

        posl.append([x + x1, y + y1])
        x += 1

        pygame.draw.circle(w, (255, 0, 0), (x, 200), 10)

        pygame.draw.circle(w, (0, 0, 0), (math.cos(a) * d + x, math.sin(a) * d + 200), 3)

        pygame.draw.line(w, (0, 0, 0), (x, 200), (math.cos(a) * 10 + x, math.sin(a) * 10 + 200), 3)

        pygame.draw.line(w, (0, 0, 0), (0, 210), (400, 210), 3)

        if x > 450:
            anim = False

    else:
        posl = []

        a = 0

        for x in range(0, 400):
            a += rollSpeed * math.pi/180
            x1 = math.cos(a) * d
            y1 = math.sin(a) * d
            
            #pygame.draw.circle(w, (0, 255, 0), (x, y), d)
            #pygame.draw.circle(w, (0, 0, 255), (200 + x3, 200 + y3), c3s * scale)

            posl.append([x + x1, y + y1])
        mx, my = pygame.mouse.get_pos()

        rollSpeed = mx/10
        d = my/10

        pygame.display.set_caption("RollSpeed: " + str(rollSpeed) + "         d: " +  str(d))

        pygame.draw.circle(w, (255, 0, 0), (200, 100), 10)

        pygame.draw.circle(w, (255, 255, 255), (math.cos(an * math.pi/180) * d + 200, math.sin(an * math.pi/180) * d + 100), 3)

        pygame.draw.line(w, (0, 0, 0), (200, 100), (math.cos(an * math.pi/180) * 10 + 200, math.sin(an * math.pi/180) * 10 + 100), 3)
    
    ind = 0
    for p in posl:
        if ind == 0:
            pygame.draw.circle(w, (255, 127, 0), (p[0], p[1]), 5)
        else:
            pygame.draw.line(w, (255, 0, 0), (p[0], p[1]), (posl[ind-1][0], posl[ind-1][1]), 1)
        ind += 1

    an += rollSpeed
    
    pygame.display.flip()
pygame.quit()
