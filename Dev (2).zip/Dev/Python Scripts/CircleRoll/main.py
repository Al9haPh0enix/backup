
import pygame
import math
pygame.init()

w = pygame.display.set_mode((400, 400))
c = pygame.time.Clock()

posl = []

c1s = 3
c2s = 2
c3s = .2
scale = 10
rollSpeed = 2
d = 0

a = 0

detail = 10

running = True
while running:
    c.tick(60)
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
    
    w.fill((127, 127, 127))
    posl = []

    

    for an in range(0, 360 * detail):
        a = (an/detail) * math.pi/180
        x1 = math.cos(a) * scale
        y1 = math.sin(a) * scale
        
        #pygame.draw.circle(w, (255, 0, 0), (200, 200), c1s * scale)
        
        x2 = x1 + (math.cos(a)*c2s*scale*2)
        y2 = y1 + (math.sin(a)*c2s*scale*2)

        x3 = x2 + (math.cos(a*rollSpeed)*d*scale)
        y3 = y2 + (math.sin(a*rollSpeed)*d*scale)
        
        #pygame.draw.circle(w, (0, 255, 0), (200 + x2, 200 + y2), c2s * scale)
        #pygame.draw.circle(w, (0, 0, 255), (200 + x3, 200 + y3), c3s * scale)

        if x3 >= -200  and x3 <= 200 and y3 >= -200 and y3 <= 200:
            posl.append([x3, y3])
    
    ind = 0
    for p in posl:
        col = ind /len(posl)
        col *= 255
        pygame.draw.circle(w, (col, 0, 0), (200+p[0], 200+p[1]), 1)
        ind += 1
    
    mx, my = pygame.mouse.get_pos()

    d = mx / 20
    rollSpeed = int(my/20)
    
    pygame.display.flip()
pygame.quit()
