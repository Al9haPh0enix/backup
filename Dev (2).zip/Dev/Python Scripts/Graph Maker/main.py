import math
import pygame
pygame.init()

def _map(x, in_min, in_max, out_min, out_max):
    return int((x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min)

w = pygame.display.set_mode([600, 600])
w.fill((255, 255, 255))

with open("input.data") as data:
    lines = data.read().split("\n")

    j = lines[0].split(" : ")
    lx = (int(j[0]) * 60, int(j[1]) * 60)

    for i in lines:
        i = i.split(" : ")
        x = (int(i[0]) * 60, _map(int(i[1]), 0, 10, 10, 0) * 60)

        pygame.draw.line(w, (0, 0, 0), lx, x, 3)
        lx = x
        pygame.display.flip()
        pygame.time.wait(10)
pygame.image.save(w, "graph.png")
pygame.time.wait(1000)

