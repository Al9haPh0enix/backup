import math
import pygame

def Sine(x, iterations):
    plus = 1
    out = 0
    for i in range(1, iterations, 2):
        out += plus*(math.pow(x, i) / math.factorial(i))
        plus = -plus
    return out

def Cosine(x, iterations):
    plus = -1
    out = 1
    for i in range(2, iterations, 2):
        out += plus*(math.pow(x, i) / math.factorial(i))
        plus = -plus
    return out

def calc_X(iterations, angle):
    return Cosine(((iterations + angle) * (math.pi/180)), 150)
def calc_Y(iterations, angle):
    return Sine(((iterations + angle) * (math.pi/180)), 150)

WIDTH = 1080
HEIGHT = 600
FPS = 30
angle = 0

lx = calc_X(0, angle)
ly = calc_Y(0, angle)

pygame.init()
screen = pygame.display.set_mode((WIDTH, HEIGHT))
running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    #screen.fill((0, 0, 0))

    for i in range(10):

        x = calc_X(i, angle)
        y = calc_Y(i, angle)

        x1 = (angle, (x*100) + (HEIGHT / 2))
        x2 = (angle - 1, (lx*100) + (HEIGHT / 2))
    
        y1 = ((y*100) + (WIDTH / 2), i + (HEIGHT/2))
        y2 = ((ly*100) + (WIDTH / 2), (i-1) + (HEIGHT/2))

        #z1 = (iterations, (x + y)*100 + (HEIGHT/2))
        #z2 = (iterations-1, (lx + ly)*100 + (HEIGHT/2))

        pygame.draw.line(screen, (255, 0, 0), x1, x2)
    
        pygame.draw.circle(screen, (0, 0, 0), (WIDTH/2, HEIGHT/2), 75)
        pygame.draw.circle(screen, (111, 111, 111), (WIDTH/2, HEIGHT/2), 50, 1)

        pygame.draw.line(screen, (255, 0, 0), ((-x*50) + (WIDTH/2), HEIGHT/2), (WIDTH/2, HEIGHT/2))
        pygame.draw.line(screen, (0, 255, 0), ((-x*50) + (WIDTH/2), HEIGHT/2), ((-x*50) + (WIDTH/2), (y*50) + (HEIGHT/2)))

        pygame.draw.line(screen, (255, 255, 255), ((-x*50) + (WIDTH/2), (y*50) + (HEIGHT/2)), (WIDTH/2, HEIGHT/2))

        pygame.draw.circle(screen, (255, 255, 255), ((-x*50) + (WIDTH/2), (y*50) + (HEIGHT/2)), 7)

        lx = x
        ly = y
    pygame.time.wait(10)

    pygame.display.flip()
    angle += 1
    if angle > 360:
        angle = 0
pygame.quit()
