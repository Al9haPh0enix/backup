def calc(x1, y1, x2, y2):
    x3 = x2-x1
    y3 = y2-y1
    return (x3, y3)

x1 = int(input("x1: "))
x2 = int(input("y2: "))
y1 = int(input("x1: "))
y2 = int(input("y2: "))

x, y = calc(x1, y1, x2, y2)

minus = False

if x < 0 or y < 0:
    minus = True
x = abs(x)
y = abs(y)
if minus:
    print("m = - " + str(y) + "/" + str(x))
else:
    print("m = " + str(y) + "/" + str(x))
