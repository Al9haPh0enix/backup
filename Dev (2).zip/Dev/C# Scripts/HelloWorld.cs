main(){
    Console.WriteLine("Hello World!");
}