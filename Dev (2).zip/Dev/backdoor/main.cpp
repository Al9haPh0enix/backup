
#include <iostream>
#include <stdlib.h>
#include <time.h>  
#include <string.h>
#include <windows.h>

/*
set path=%PATH%;C:/msys64/mingw64/bin
cd C:\Users\hammersmarkm\Documents\Dev\backdoor
g++ main.cpp & a.exe

*/

//random, including min and max
int random(int min, int max){
    return (rand()%(max-min+1))+min;
}

int main(){

    int dif = 10;

    srand(time(NULL));
    for(int i = 0; i < 100; i++){
        std::string s = "";
        int j = 0;
        for(j = 0; j < random(i-dif, i+dif); j++){
            s = s + " ";
        }
        s = s + "#";

        std::cout<< s << "\n";
        Beep ((j*5)+440, 100);
        Sleep(100);
    }
}