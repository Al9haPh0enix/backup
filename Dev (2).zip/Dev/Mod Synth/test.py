import numpy as np
import matplotlib.pyplot as plt

sr = 44100
freq = 3

for i in range(1, 10):
    val = 1/i

    t = np.arange(0, 1, 1/sr)

    signal = np.sin(2*np.pi*freq*t)

    signal = np.clip(signal, -val, val) * (1/val)

    plt.plot(t, signal)
plt.show()